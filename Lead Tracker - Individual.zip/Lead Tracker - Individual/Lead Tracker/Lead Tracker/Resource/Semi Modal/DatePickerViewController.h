//
//  DatePickerViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 26/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "TDSemiModalViewController.h"
#import "TDSemiModal.h"
@interface DatePickerViewController : TDSemiModalViewController

@property (nonatomic, strong)  id delegate;
@property (nonatomic, retain) NSArray *pickerData;

@property (retain, nonatomic) IBOutlet UIDatePicker *picker;
@property (retain, nonatomic) IBOutlet UIToolbar *toolbar;

-(IBAction)doneAction:(id)sender;

-(IBAction)cancelAction:(id)sender;
@end

@interface NSObject (DatePickerViewControllerDelegate)
-(void)pickerDone:(DatePickerViewController*)viewController;
-(void)pickerCancel:(DatePickerViewController *)viewController;
@end
