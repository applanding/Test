//
//  AppDelegate.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 17/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    FBSession* session = [FBSession activeSession];
    [session closeAndClearTokenInformation];
    [session close];
    [FBSession setActiveSession:nil];
    
    [[DatabaseHelper sharedInstance]openDB];
    [[DatabaseHelper sharedInstance]checkAndCreateTables];
    
    NSHTTPCookieStorage* cookies = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray* facebookCookies = [cookies cookiesForURL:[NSURL         URLWithString:@"https://facebook.com/"]];
    
    for (NSHTTPCookie* cookie in facebookCookies) {
        [cookies deleteCookie:cookie];
    }

    
    
    [[UIApplication sharedApplication]setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [[AFNetworkActivityIndicatorManager sharedManager] setEnabled:YES];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    
    if (!EventSingular) {
        [[NSUserDefaults standardUserDefaults]setValue:@"Meeting" forKey:@"EventSingular"];
        [[NSUserDefaults standardUserDefaults]setValue:@"Meetings" forKey:@"EventPlural"];
        [[NSUserDefaults standardUserDefaults]setValue:@"Contact" forKey:@"LeadSingular"];
        [[NSUserDefaults standardUserDefaults]setValue:@"Contacts" forKey:@"LeadPlural"];
        
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    
    if (![[NSUserDefaults standardUserDefaults]valueForKey:@"SavedURL"]) {
        [[NSUserDefaults standardUserDefaults]setValue:[NSString stringWithFormat:@"%@",DEFAULT_URL] forKey:@"SavedURL"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    [self performSelector:@selector(StartApplication) withObject:nil afterDelay:0.4];
    
//    for (NSString *fontFamilyName in [UIFont familyNames]) {
//        for (NSString *fontName in [UIFont fontNamesForFamilyName:fontFamilyName]) {
//            NSLog(@"Family: %@    Font: %@", fontFamilyName, fontName);
//        }
//    }
    
    return YES;
}
-(void)StartApplication{
   
    
    ViewController *mainController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:mainController];
    navController.navigationBarHidden = YES;
    if ([navController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        navController.interactivePopGestureRecognizer.enabled = NO;
    }
    self.window.rootViewController = navController;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    if(!Is_local && OptionSelected){
    [[ModelClass sharedInstance]GetEventLabel:
    ^(id result){
        for (NSDictionary *dict in result) {
            if ([[dict valueForKey:@"name"]isEqualToString:@"event"]) {
                [[NSUserDefaults standardUserDefaults]setValue:[dict valueForKey:@"singular"] forKey:@"EventSingular"];
                [[NSUserDefaults standardUserDefaults]setValue:[dict valueForKey:@"plural"] forKey:@"EventPlural"];
            }
            if ([[dict valueForKey:@"name"]isEqualToString:@"lead"]) {
                [[NSUserDefaults standardUserDefaults]setValue:[dict valueForKey:@"singular"] forKey:@"LeadSingular"];
                [[NSUserDefaults standardUserDefaults]setValue:[dict valueForKey:@"plural"] forKey:@"LeadPlural"];
            }
        }
       
        [[NSUserDefaults standardUserDefaults]synchronize];
    } error:^(NSError *error){
    
    }];
    }
    // Logs 'install' and 'app activate' App Events.
    [FBAppEvents activateApp];
    
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [[DatabaseHelper sharedInstance]closeDB];
}
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
   
    if([[url absoluteString]  hasPrefix:[NSString stringWithFormat:@"fb%@",FacebookAppId]]){
        return [FBAppCall handleOpenURL:url sourceApplication:sourceApplication];
    }else{
        return [GPPURLHandler handleURL:url
                      sourceApplication:sourceApplication
                             annotation:annotation];
    }
    return NO;
    
}
-(NSString *) getRandomString{
    NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    NSMutableString *randomString = [NSMutableString stringWithCapacity:10];
    
    for (int i=0; i<10; i++) {
        [randomString appendFormat: @"%C", [letters characterAtIndex:(int)arc4random_uniform((int)[letters length])]];
    }
    
    return randomString;
}
@end
