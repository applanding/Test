//
//  ModelClass.m
//  APITest
//
//  Created by Evgeny Kalashnikov on 03.12.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ModelClass.h"



@implementation ModelClass


- (id)init
{
    self = [super init];
    if (self) {
       drkSignUp = [[DarckWaitView alloc] initWithDelegate:nil andInterval:0.1 andMathod:nil];
    }
    
    return self;
}
+ (ModelClass *)sharedInstance{

    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (void) doLoginwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
  
    [self postURL:@"login" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void) doRegisterwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    
    [self postURL:@"register" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}

- (void) forgotPasswordwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    [self postURL:@"forgotpassword" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)GetProfilewithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    [self postURL:@"getprofile" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)updateProflewithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    
    [self postURL:@"updateprofile" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)eventlistwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    
    [self postURL:@"eventlist" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)addorediteventwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    
    [self postURL:@"addeditevent" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}

- (void)eventCommentlistwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    
    [self postURL:@"eventcommentlist" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)Leadlistwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    
    [self postURL:@"leadlist" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)AddorEditLeadlistwithparamter:(NSDictionary *)parameters images:(NSMutableArray *)images success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    
    [self postURL:@"addeditlead" parameters:parameters images:images success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)AddCommentwithparamter:(NSDictionary *)parameters is_audio:(BOOL)is_audio success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    if (is_audio) {
    
    [self postURLWithAudio:@"addcomment" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
    }else{
        [self postURL:@"addcomment" parameters:parameters success:^(id response) {
            result(response);
        } failure:^(NSError *anError) {
            error(anError);
        }];
    
    }
}
- (void)LeadCommentlistwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    
    [self postURL:@"commentlist" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}

- (void)GetInfoTextwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    [self postURL:@"cms" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];;
}
- (void)SearchEventLeadwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    [self postURL:@"searcheventlead" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];;
}
- (void)GetEventLabel:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    [self postURL:@"eventlabel" parameters:nil success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];
}
- (void)SocialLoginwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    [self postURL:@"socialregister" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];;
}
- (void)DeleteRecordwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    [self postURL:@"delete" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];;
}
- (void)GetCommentCountwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error
{
    
    [self postURL:@"commentcount" parameters:parameters success:^(id response) {
        result(response);
    } failure:^(NSError *anError) {
        error(anError);
    }];;
}



-(void)postURL:(NSString *)URL parameters:(NSDictionary *)parameters success: (void (^) (id result)) successBlock failure: (void (^) (NSError * error)) failureBlock{

  //  if ([self canConnect:API_PATH]) {
     if ([AFNetworkReachabilityManager sharedManager].reachable) {
        if(![[parameters valueForKey:@"start"]intValue]>0){
        [drkSignUp showWithMessage:nil];
        }
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
    [manager POST:[[NSString stringWithFormat:@"%@%@",API_PATH,URL]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
 //      NSLog(@"JSON: %@", responseObject);
        [drkSignUp hide];
        successBlock(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"Error: %@", operation.responseString);
        [drkSignUp hide];
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Your app is having trouble connecting to our system. Please check your internet connection and try again. If the problem continues then please contact us through our website www.meetingtalks.com" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
        failureBlock(error);
    }];
    }else{
    
        [[[UIAlertView alloc] initWithTitle:@"" message:@"This app requires an internet connection. Please  check that your internet is working and then retry." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    
}
-(void)postURL:(NSString *)URL parameters:(NSDictionary *)parameters images:(NSMutableArray *)arr_image success: (void (^) (id result)) successBlock failure: (void (^) (NSError * error)) failureBlock{
    
 //   if ([self canConnect:API_PATH]) {
     if ([AFNetworkReachabilityManager sharedManager].reachable) {
        if(![[parameters valueForKey:@"start"]intValue]>0){
            [drkSignUp showWithMessage:nil];
        }
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
        [manager POST:[[NSString stringWithFormat:@"%@%@",API_PATH,URL]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            //do not put image inside parameters dictionary as I did, but append it!
            for (int i = 0; i<[arr_image count]; i++) {
                if (![[arr_image objectAtIndex:i] isEqual:[UIImage imageNamed:@"add_image"]]) {
                    
                    NSData *imgData = [[NSData alloc] initWithData:UIImageJPEGRepresentation(([self scaleAndRotateImage:[arr_image objectAtIndex:i]]), 1)];
                    if (imgData.length >2) {
                        if(i == 0){
                            [formData appendPartWithFileData:imgData name:@"card" fileName:[NSString stringWithFormat:@"%@.jpg",[NSString stringWithFormat:@"%u",arc4random()]] mimeType:@"image/jpeg"];
                        }else{
                            [formData appendPartWithFileData:imgData name:@"pic" fileName:[NSString stringWithFormat:@"%@.jpg",[NSString stringWithFormat:@"%u",arc4random()]] mimeType:@"image/jpeg"];
                        }
                    }
                }
            }
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
         //   NSLog(@"JSON: %@", responseObject);
            [drkSignUp hide];
            successBlock(responseObject);
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
            [drkSignUp hide];
            [[[UIAlertView alloc] initWithTitle:@"" message:@"Your app is having trouble connecting to our system. Please check your internet connection and try again. If the problem continues then please contact us through our website www.meetingtalks.com" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            failureBlock(error);
        }];
        
    
    }else{
        
        [[[UIAlertView alloc] initWithTitle:@"" message:@"This app requires an internet connection. Please  check that your internet is working and then retry." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    
}
-(void)postURLWithAudio:(NSString *)URL parameters:(NSDictionary *)parameters success: (void (^) (id result)) successBlock failure: (void (^) (NSError * error)) failureBlock{
    
//    if ([self canConnect:API_PATH]) {
     if ([AFNetworkReachabilityManager sharedManager].reachable) {
        if(![[parameters valueForKey:@"start"]intValue]>0){
            [drkSignUp showWithMessage:nil];
        }
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
        [manager POST:[[NSString stringWithFormat:@"%@%@",API_PATH,URL]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            //do not put image inside parameters dictionary as I did, but append it!
            
            NSData *audiodata = [NSData dataWithContentsOfURL:[NSURL fileURLWithPath:[NSHomeDirectory() stringByAppendingFormat:@"/Documents/%@", @"Mp3File.mp3"]]];
            [formData appendPartWithFileData:audiodata name:@"audio" fileName:[NSString stringWithFormat:@"%@.mp3",[NSString stringWithFormat:@"%u",arc4random()]] mimeType:@"audio/mp3"];
            
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
         //   NSLog(@"JSON: %@", responseObject);
            [drkSignUp hide];
            successBlock(responseObject);
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"Error: %@", error);
            [drkSignUp hide];
            [[[UIAlertView alloc] initWithTitle:@"" message:@"Your app is having trouble connecting to our system. Please check your internet connection and try again. If the problem continues then please contact us through our website www.meetingtalks.com" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            failureBlock(error);
        }];
        
        
    }else{
        
        [[[UIAlertView alloc] initWithTitle:@"" message:@"This app requires an internet connection. Please  check that your internet is working and then retry." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    
}



- (BOOL) validateEmail: (NSString *)candidate {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    
    return [emailTest evaluateWithObject:candidate];
}
- (UIImage *)scaleAndRotateImage:(UIImage *)image { // here we rotate the image in its orignel
    int kMaxResolution = 640; // Or whatever
    
    CGImageRef imgRef = image.CGImage;
    
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
    
    
    CGAffineTransform transform = CGAffineTransformIdentity;
    CGRect bounds = CGRectMake(0, 0, width, height);
    if (width > kMaxResolution || height > kMaxResolution) {
        CGFloat ratio = width/height;
        if (ratio > 1) {
            bounds.size.width = kMaxResolution;
            bounds.size.height = roundf(bounds.size.width / ratio);
        }
        else {
            bounds.size.height = kMaxResolution;
            bounds.size.width = roundf(bounds.size.height * ratio);
        }
    }
    
    CGFloat scaleRatio = bounds.size.width / width;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    UIImageOrientation orient = image.imageOrientation;
    switch(orient) {
            
        case UIImageOrientationUp: //EXIF = 1
            transform = CGAffineTransformIdentity;
            break;
            
        case UIImageOrientationUpMirrored: //EXIF = 2
            transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            break;
            
        case UIImageOrientationDown: //EXIF = 3
            transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationDownMirrored: //EXIF = 4
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformScale(transform, 1.0, -1.0);
            break;
            
        case UIImageOrientationLeftMirrored: //EXIF = 5
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
            transform = CGAffineTransformScale(transform, -1.0, 1.0);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationRightMirrored: //EXIF = 7
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeScale(-1.0, 1.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        case UIImageOrientationRight: //EXIF = 8
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        default:
            [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
            
    }
    
    UIGraphicsBeginImageContext(bounds.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
        CGContextScaleCTM(context, -scaleRatio, scaleRatio);
        CGContextTranslateCTM(context, -height, 0);
    }
    else {
        CGContextScaleCTM(context, scaleRatio, -scaleRatio);
        CGContextTranslateCTM(context, 0, -height);
    }
    
    CGContextConcatCTM(context, transform);
    
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
    UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return imageCopy;
}
@end