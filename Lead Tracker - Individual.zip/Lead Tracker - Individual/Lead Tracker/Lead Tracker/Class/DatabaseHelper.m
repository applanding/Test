//
//  DatabaseHelper.m
//  TenderTiger
//
//  Created by ETL on 17/11/14.
//  Copyright (c) 2014 ETL. All rights reserved.
//

#import "DatabaseHelper.h"

@implementation DatabaseHelper

+ (DatabaseHelper *)sharedInstance
{
    static DatabaseHelper *sharedInstance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
        
    });
    return sharedInstance;
}
#pragma mark - Create Methods
-(void)checkAndCreateTables{
    NSString *strQuery =  @"CREATE TABLE comments"
    @"(id integer PRIMARY KEY AUTOINCREMENT,"
    @"event_id integer,"
    @"lead_id integer,"
    @"comment text,"
    @"type bit DEFAULT(0),"
    @"audio_file text,"
    @"i_date integer,"
    @"is_active bit DEFAULT(1),"
    @"is_deleted bit DEFAULT(0))";
    
    if (![_db tableExists:@"comments"])
    {
        [self executeUpdate:strQuery andCompletionBlock:^(BOOL success){
            if (success){
               
            }
            else{
                
            }
        }];
    }
    
    strQuery =  @"CREATE TABLE events"
    @"(id integer PRIMARY KEY AUTOINCREMENT,"
    @"event_name text,"
    @"location text,"
    @"event_date integer,"
    @"end_date integer,"
    @"i_date integer,"
    @"u_date integer,"
    @"is_active bit DEFAULT(1),"
    @"is_deleted bit DEFAULT(0))";
    
    if (![_db tableExists:@"events"])
    {
        [self executeUpdate:strQuery andCompletionBlock:^(BOOL success){
            if (success){
                
            }
            else{
              
            }
        }];
    }
    
    strQuery =  @"CREATE TABLE leads"
    @"(id integer PRIMARY KEY AUTOINCREMENT,"
    @"event_id integer,"
    @"company text,"
    @"first_name text,"
    @"last_name text,"
    @"email text,"
    @"phone text,"
    @"card_image text,"
    @"pic_image text,"
    @"i_date integer,"
    @"u_date integer,"
    @"is_active bit DEFAULT(1),"
    @"is_deleted bit DEFAULT(0))";
    
    if (![_db tableExists:@"leads"])
    {
        [self executeUpdate:strQuery andCompletionBlock:^(BOOL success){
            if (success){
               
            }
            else{
               
            }
        }];
    }
    
}
-(NSString *) checkAndCreateDatabase{
    
    // Get the path to the documents directory and append the databaseName
    // NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    // NSString *documentsDir = [documentPaths objectAtIndex:0];
    
   
    
    //NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    
    NSString  *databasePath =[NSString stringWithFormat:@"%@",[Document_Directory stringByAppendingPathComponent:@"meetingtalks_db.sqlite"]];
   
    // Check if the SQL database has already been saved to the users phone, if not then copy it over
    
    
    // Create a FileManager object, we will use this to check the status
    // of the database and to copy it over if required
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    // Check if the database has already been created in the users filesystem
    BOOL success = [fileManager fileExistsAtPath:databasePath];
    
    // If the database already exists then return without doing anything
    if(success)
    {
        //[pool release];
        return databasePath;
    }
    
    // If not then proceed to copy the database from the application to the users filesystem
    
    // Get the path to the database in the application package
    NSString *databasePathFromApp = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"meetingtalks_db.sqlite"];
    
    
    
    // Copy the database from the package to the users filesystem
    [fileManager copyItemAtPath:databasePathFromApp toPath:databasePath error:nil];
    
    //[pool release];
    return databasePath;
    
}
#pragma mark - Execution Method
- (void) openDB
{
    @autoreleasepool {
        /* FMDatabase here is used to take the database path */
        _db  = [[FMDatabase alloc] initWithPath:[self checkAndCreateDatabase]];
        _queue = [FMDatabaseQueue databaseQueueWithPath:[self checkAndCreateDatabase]];
        
        //[db setTraceExecution:YES];
        
        /* Here we are opening the datase in order to access it */
        [_db open];
        [_db setLogsErrors:YES];
    }
}
- (void) closeDB
{
    /* Closing the Database */
    [_db close];
}
-(void)executeQuery:(NSString *)Query andCompletionBlock:(void(^)(FMResultSet *fResult))completionBlock
{
    [_queue inDatabase:^(FMDatabase *db) {
        FMResultSet *fResult = [db executeQuery:[NSString stringWithFormat:@"%@",Query]];
        completionBlock(fResult);
       
        }];

    
}


- (void) executeUpdate:(NSString*)Query andCompletionBlock:(void(^)(BOOL success))completionBlock
{
    
    [_queue inDatabase:^(FMDatabase *db) {
         BOOL success = [db executeUpdate:Query];
        completionBlock(success);
    }];
    
//    [_queue inTransaction:^(FMDatabase *db, BOOL *rollback) {
//        BOOL success = [db executeUpdate:Query];
//        completionBlock(success);
//    }];
   
}
@end
