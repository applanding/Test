//
//  EventListViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 23/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddEventViewController.h"
#import "EventTableViewCell.h"
#import "AddEventViewController.h"
#import "EventDetailViewController.h"
#import "DemoTableFooterView.h"
#import "SearchViewController.h"
@interface EventListViewController : UIViewController<UISearchBarDelegate>
{
    NSMutableArray *arr_upcomingoriginal;
    NSMutableArray *arr_upcomingdisplay;
    BOOL isLoadingMore_upcoming;
    BOOL canLoadMore_upcoming;
  
}

@property (weak, nonatomic) IBOutlet UISearchBar *txt_search;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
- (IBAction)goBack:(id)sender;
- (IBAction)goAddEvent:(id)sender;
@property (nonatomic, retain) DemoTableFooterView *footerView;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@end
