//
//  EventDetailViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 24/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DemoTableFooterView.h"
#import "CommentTableViewCell.h"
#import "LeadsListViewController.h"
#import "FSAudioStream.h"
#import "FSAudioController.h"
#import "FSPlaylistItem.h"
#import "FSFrequencyDomainAnalyzer.h"
#import "FSFrequencyPlotView.h"
#import "AJNotificationView.h"
@interface EventDetailViewController : UIViewController<UITableViewDataSource, UITableViewDelegate,UISearchBarDelegate,FSPCMAudioStreamDelegate>
{
   
    BOOL isLoadingMore;
    BOOL canLoadMore;
    NSMutableArray *displayarr;
    NSMutableArray *originalarr;
    
    NSTimer *_progressUpdateTimer;
    FSPlaylistItem *_selectedPlaylistItem;
    FSAudioController *_controller;
    
}
@property (weak, nonatomic) IBOutlet UIButton *btn_leads;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (nonatomic,strong) UIButton *playButton;
@property (nonatomic,strong) FSPlaylistItem *selectedPlaylistItem;
@property (nonatomic,strong) UISlider *progressSlider;
@property (nonatomic,strong) FSAudioController *audioController;
- (IBAction)goBack:(id)sender;
- (IBAction)goEdit:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_eventname;
@property (weak, nonatomic) IBOutlet UILabel *lbl_location;
@property (weak, nonatomic) IBOutlet UILabel *lbl_date;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (retain, nonatomic) NSMutableDictionary *eventDict;
 @property (nonatomic, retain) DemoTableFooterView *footerView;
@property (weak, nonatomic) IBOutlet UIView *view_detail;
- (IBAction)goLeads:(id)sender;
@property (weak, nonatomic) IBOutlet UISearchBar *txt_search;

@end
