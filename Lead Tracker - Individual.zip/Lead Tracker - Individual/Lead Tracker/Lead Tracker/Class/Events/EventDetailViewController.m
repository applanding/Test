//
//  EventDetailViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 24/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "EventDetailViewController.h"

@interface EventDetailViewController ()

@end

@implementation EventDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
   
    _selectedPlaylistItem = [[FSPlaylistItem alloc]init];
    _view_detail.layer.cornerRadius = 5.0;
    
    _lbl_eventname.text = [NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"name"]];
    _lbl_location.text = [NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"location"]];
    _lbl_date.text = [NSString stringWithFormat:@"%@-%@",[_eventDict valueForKey:@"startdate"],[_eventDict valueForKey:@"enddate"]];
    [self CallCommentListAPI];
    _lbl_title.text = [NSString stringWithFormat:@"%@ Detail",EventSingular];
    [_btn_leads setTitle:LeadPlural forState:UIControlStateNormal];
    
}
-(void)viewWillAppear:(BOOL)animated{
    if (DELEGATE.is_refresh) {
        DELEGATE.is_refresh = NO;
        [self CallCommentListAPI];
        
    }
    [self.audioController setVolume:1.0];
    
    self.audioController.stream.onStateChange = ^(FSAudioStreamState state) {
        switch (state) {
            case kFsAudioStreamRetrievingURL:
                [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
                
                [self showStatus:@"Retrieving URL..."];
                
                self.progressSlider.enabled = NO;
                self.playButton.selected = YES;
                
                
                break;
                
            case kFsAudioStreamStopped:
                [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                
               
                
                self.progressSlider.enabled = NO;
                self.playButton.selected = NO;
                
               
                break;
                
            case kFsAudioStreamBuffering:
                [self showStatus:@"Buffering..."];
                
                [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
                self.progressSlider.enabled = NO;
                self.playButton.selected = YES;
                
                break;
                
            case kFsAudioStreamSeeking:
                [self showStatus:@"Seeking..."];
                
                [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
                self.progressSlider.enabled = NO;
                self.playButton.selected = YES;
               
                break;
                
            case kFsAudioStreamPlaying:
               
                [self clearStatus];
                
                [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                
                self.progressSlider.enabled = YES;
                
                if (!_progressUpdateTimer) {
                    _progressUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                                                            target:self
                                                                          selector:@selector(updatePlaybackProgress)
                                                                          userInfo:nil
                                                                           repeats:YES];
                }
                
                self.playButton.selected = YES;
                
               
                
                break;
                
            case kFsAudioStreamFailed:
                [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                self.progressSlider.enabled = NO;
                self.playButton.selected = NO;
               
               
                break;
            default:
                break;
        }
    };
    
    self.audioController.stream.onFailure = ^(FSAudioStreamError error, NSString *errorDescription) {
        NSString *errorCategory;
        
        switch (error) {
            case kFsAudioStreamErrorOpen:
                errorCategory = @"Cannot open the audio stream: ";
                break;
            case kFsAudioStreamErrorStreamParse:
                errorCategory = @"Cannot read the audio stream: ";
                break;
            case kFsAudioStreamErrorNetwork:
                errorCategory = @"Network failed: cannot play the audio stream: ";
                break;
            case kFsAudioStreamErrorUnsupportedFormat:
                errorCategory = @"Unsupported format: ";
                break;
            case kFsAudioStreamErrorStreamBouncing:
                errorCategory = @"Network failed: cannot get enough data to play: ";
                break;
            default:
                errorCategory = @"Unknown error occurred: ";
                break;
        }
        
        NSString *formattedError = [NSString stringWithFormat:@"%@ %@", errorCategory, errorDescription];
        
        [self showErrorStatus:formattedError];
    };
    
}
-(void)viewDidAppear:(BOOL)animated{
    [self becomeFirstResponder];
    
    _progressUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                                            target:self
                                                          selector:@selector(updatePlaybackProgress)
                                                          userInfo:nil
                                                           repeats:YES];

}
-(void)CallCommentListAPI{
    _footerView = (DemoTableFooterView *) [[[NSBundle mainBundle] loadNibNamed:@"DemoTableFooterView" owner:self options:nil] objectAtIndex:0];
    _tableview.tableFooterView = _footerView;
    canLoadMore = YES;
    if (Is_local) {
       
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"select comments.id,comments.comment,comments.type,comments.audio_file,comments.i_date,leads.first_name,leads.last_name from comments Inner Join leads on leads.id = comments.lead_id where comments.is_active = 1 and comments.is_deleted = 0 and comments.event_id='%@' order by comments.i_date desc LIMIT %d OFFSET 0 ",[_eventDict valueForKey:@"id"],Limit] andCompletionBlock:^(FMResultSet *fresults){
            originalarr = [[NSMutableArray alloc]init];
            displayarr = [[NSMutableArray alloc]init];
            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];
            
            NSDateFormatter *_timeformat = [[NSDateFormatter alloc] init];
            [_timeformat setDateFormat:@"hh:mm a"];
            while ([fresults next]) {
               
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"audio_file"]] forKey:@"audio"];
               
                NSDate *commentdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"i_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:commentdate] forKey:@"date"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"comment"]] forKey:@"text"];
                [dict setObject:@"T" forKey:@"type"];
                if([[[fresults resultDictionary]valueForKey:@"type"]intValue]==1){
                [dict setObject:@"A" forKey:@"type"];
                }
                [dict setObject:[_timeformat stringFromDate:commentdate] forKey:@"time"];
                [originalarr addObject:dict];
            }
                displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
                if ([originalarr count] < Limit) {
                    canLoadMore = NO;
                }
                [_tableview reloadData];
                [self loadMoreCompleted];
                _tableview.hidden = NO;
        }];
    }else{
    [[ModelClass sharedInstance]eventCommentlistwithparamter:
     @{@"userid":User_Id,
       @"eventid":[NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"id"]],
       @"start":@"0",
       @"limit":[NSString stringWithFormat:@"%d",Limit]
       }
        success:^(id result){
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                originalarr = [[NSMutableArray alloc]initWithArray:[result valueForKey:@"Comment"]];
                displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
                
            }else{
                //   [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            }
            
            if ([originalarr count] < Limit) {
                canLoadMore = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompleted];
            _tableview.hidden = NO;
        } error:^(NSError *error){
            canLoadMore = NO;
        }];
    }
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
   
    return [displayarr count];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([[[displayarr objectAtIndex:indexPath.row]valueForKey:@"type"]isEqualToString:@"T"]) {
    
     return  [[NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"text"]] sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(320 - 17, MAXFLOAT)lineBreakMode:NSLineBreakByWordWrapping].height + 55;
        
        
    }
    
    return 80;
}

-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CommentTableViewCell *cell;
    if ([[[displayarr objectAtIndex:indexPath.row]valueForKey:@"type"]isEqualToString:@"T"]) {
    
    static NSString *CellIdentifier = @"CommentTableViewCell";
    cell = (CommentTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell= (CommentTableViewCell *)[arrNib objectAtIndex:0];
    }
         cell.lbl_comment.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"text"]];
        [cell.lbl_comment sizeToFit];
        [cell.lbl_date setFrame:CGRectMake(cell.lbl_date.frame.origin.x, cell.lbl_comment.frame.origin.y + cell.lbl_comment.frame.size.height + 5, cell.lbl_date.frame.size.width, cell.lbl_date.frame.size.height)];
        [cell.lbl_time setCenter:CGPointMake(cell.lbl_time.center.x, cell.lbl_date.center.y)];
        
    }else{
        static NSString *CellIdentifier = @"AudioCommentTableViewCell";
        cell = (CommentTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell==nil) {
            NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell= (CommentTableViewCell *)[arrNib objectAtIndex:0];
        }
        cell.btn_play.tag = indexPath.row;
        [cell.btn_play addTarget:self action:@selector(PlayComment:) forControlEvents:UIControlEventTouchUpInside];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.lbl_name.text = [NSString stringWithFormat:@"%@ %@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"firstname"],[[displayarr objectAtIndex:indexPath.row]valueForKey:@"lastname"]];
    cell.lbl_date.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"date"]];
    cell.lbl_time.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"time"]];
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
   
   
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        if (Is_local) {
            [[DatabaseHelper sharedInstance]executeUpdate:[NSString stringWithFormat:@"Update comments set is_active = 0 and is_deleted = 1 where id = %@ ",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"id"]] andCompletionBlock:^(BOOL Success){
                if (Success) {
                     if (![[[displayarr objectAtIndex:indexPath.row]valueForKey:@"type"]isEqualToString:@"T"]) {
                        [[NSFileManager defaultManager]removeItemAtPath:[Document_Directory stringByAppendingPathComponent:[[displayarr objectAtIndex:indexPath.row]valueForKey:@"audio"]] error:nil];
                    }

                    [originalarr removeObject:[displayarr objectAtIndex:indexPath.row]];
                    [displayarr removeObjectAtIndex:indexPath.row];
                    [_tableview deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationFade];
                }
            }];
        }else{
            [[ModelClass sharedInstance]DeleteRecordwithparamter:
             @{@"typeid":[NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"id"]],
               @"type":@"c"
               } success:^(id result){
                   [originalarr removeObject:[displayarr objectAtIndex:indexPath.row]];
                   [displayarr removeObjectAtIndex:indexPath.row];
                   [_tableview deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationFade];
               } error:^(NSError *error){
                   
               }];
        }
    }
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //    float endScrolling = scrollView.contentOffset.y + scrollView.frame.size.height;
    //    if (endScrolling >= scrollView.contentSize.height)
    //    {
    //        // your code goes here
    //    }
    
    if (!isLoadingMore && canLoadMore && _txt_search.text.length == 0) {
        CGFloat scrollPosition = scrollView.contentSize.height - scrollView.frame.size.height - scrollView.contentOffset.y;
        if (scrollPosition < [self footerLoadMoreHeight]) {
            [self loadMore];
        }
    }
}
- (CGFloat) footerLoadMoreHeight
{
    if (_footerView)
        return _footerView.frame.size.height;
    else
        return 52;
}
- (BOOL) loadMore
{
    if (isLoadingMore)
        return NO;
    
    [self willBeginLoadingMore];
    isLoadingMore = YES;
    return YES;
}
- (void) willBeginLoadingMore
{
    
    [self.footerView.activityIndicator startAnimating];
    [self performSelector:@selector(addItemsOnBottom) withObject:nil afterDelay:1.0];
}
-(void)addItemsOnBottom{
    if(Is_local){
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"select comments.id,comments.comment,comments.type,comments.audio_file,comments.i_date,leads.first_name,leads.last_name from comments Inner Join leads on leads.id = comments.lead_id where comments.is_active = 1 and comments.is_deleted = 0 and comments.event_id='%@' order by comments.i_date desc LIMIT %d OFFSET %d ",[_eventDict valueForKey:@"id"],Limit,(int)[originalarr count]] andCompletionBlock:^(FMResultSet *fresults){
            int rescount = 0;
            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];
            NSDateFormatter *_timeformat = [[NSDateFormatter alloc] init];
            [_timeformat setDateFormat:@"hh:mm a"];
            while ([fresults next]) {
                rescount++;
               
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"audio_file"]] forKey:@"audio"];
                
                NSDate *commentdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"i_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:commentdate] forKey:@"date"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"comment"]] forKey:@"text"];
                [dict setObject:@"T" forKey:@"type"];
                if([[[fresults resultDictionary]valueForKey:@"type"]intValue]==1){
                    [dict setObject:@"A" forKey:@"type"];
                }
                [dict setObject:[_timeformat stringFromDate:commentdate] forKey:@"time"];
                [originalarr addObject:dict];
            }
            displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
            if (rescount < Limit) {
                canLoadMore = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompleted];
           
            
            
        }];
    }else{
    [[ModelClass sharedInstance]eventCommentlistwithparamter:
     @{@"userid":User_Id,
       @"eventid":[NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"id"]],
       @"start":[NSString stringWithFormat:@"%d",(int)[originalarr count]],
       @"limit":[NSString stringWithFormat:@"%d",Limit]
       }
        success:^(id result){
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                [originalarr addObjectsFromArray:[result valueForKey:@"Comment"]];
                displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
                if ([[result valueForKey:@"Comment"]count] < Limit) {
                    canLoadMore = NO;
                }
            }else{
                canLoadMore = NO;
              //  [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            }
            

            [_tableview reloadData];
            [self loadMoreCompleted];
           
        } error:^(NSError *error){
            canLoadMore = NO;
        }];
    
    }
    
    
}

- (void) loadMoreCompleted
{
    
    
    [self.footerView.activityIndicator stopAnimating];
    isLoadingMore = NO;
    if (!canLoadMore) {
        // Do something if there are no more items to load
        
        // We can hide the footerView by: [self setFooterViewVisibility:NO];
        
        // Just show a textual info that there are no more items to load
        self.footerView.infoLabel.hidden = NO;
    }
}
- (void) setFooterViewVisibility:(BOOL)visible
{
    if (visible && self.tableview.tableFooterView != _footerView)
        self.tableview.tableFooterView = _footerView;
    else if (!visible)
        self.tableview.tableFooterView = nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];

}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    [displayarr removeAllObjects];
    
    NSPredicate *p = [NSPredicate predicateWithFormat:@"SELF.firstname CONTAINS[cd] %@ or SELF.lastname CONTAINS[cd] %@ or SELF.text CONTAINS[cd] %@ or SELF.date CONTAINS[cd] %@ or SELF.time CONTAINS[cd] %@", _txt_search.text, _txt_search.text, _txt_search.text,_txt_search.text,_txt_search.text];
    NSArray *arr = [originalarr filteredArrayUsingPredicate:p];
    
    if ([_txt_search.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0) {
        
        [displayarr addObjectsFromArray:arr];
        
    }else
    {
        [displayarr addObjectsFromArray:originalarr];
        
    }
    [_tableview reloadData];}
- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)goEdit:(id)sender {
    AddEventViewController *goadd = [[AddEventViewController alloc]initWithNibName:@"AddEventViewController" bundle:nil];
    goadd.is_Edit = YES;
    goadd.eventDict = _eventDict;
    [self.navigationController pushViewController:goadd animated:YES];
}
- (IBAction)goLeads:(id)sender {
    LeadsListViewController *golist = [[LeadsListViewController alloc]initWithNibName:@"LeadsListViewController" bundle:nil];
    golist.eventDict = _eventDict ;
    [self.navigationController pushViewController:golist animated:YES];
    
}
-(void)PlayComment:(UIButton *)sender{
     [self.view endEditing:YES];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback
                                     withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker
                                           error:nil];
  if (sender.isSelected) {
        //playing already
         [self.audioController pause];
        [self.audioController stop];
         sender.selected = NO;
    }else{
        
        _playButton.selected = NO;
        _progressSlider.value = 0.0;
        CommentTableViewCell *cell = (CommentTableViewCell*)[_tableview cellForRowAtIndexPath:[NSIndexPath indexPathForRow:sender.tag inSection:0]];
        for (UIView *view in cell.contentView.subviews){
            
            if ([view isKindOfClass:[UISlider class]]) {
                _progressSlider = (UISlider *)view;
                break;
            }
        }
        for (UIView *view in cell.contentView.subviews){
            
            if ([view isKindOfClass:[UIButton class]]) {
                _playButton = (UIButton *)view;
                break;
            }
        }
        FSPlaylistItem *item = [[FSPlaylistItem alloc]init];
        if ([[[displayarr objectAtIndex:sender.tag]valueForKey:@"audio"] rangeOfString:@"aud_"].location == NSNotFound) {
            
        item.url = [NSString stringWithFormat:@"%@/%@",Img_Path,[[displayarr objectAtIndex:sender.tag]valueForKey:@"audio"]];
        }else{
         item.url = [Document_Directory stringByAppendingPathComponent:[[displayarr objectAtIndex:sender.tag]valueForKey:@"audio"]];
        }
        
        [self setSelectedPlaylistItem:item];
        [self.audioController play];
        sender.selected = YES;
    }
    
   
    
}
- (FSAudioController *)audioController
{
    if (!_audioController) {
        _audioController = [[FSAudioController alloc] init];
    }
    return _audioController;
}
- (void)setSelectedPlaylistItem:(FSPlaylistItem *)selectedPlaylistItem
{
    _selectedPlaylistItem = selectedPlaylistItem;
    
    self.navigationItem.title = self.selectedPlaylistItem.title;
    
    self.audioController.url = self.selectedPlaylistItem.nsURL;
}

- (FSPlaylistItem *)selectedPlaylistItem
{
    return _selectedPlaylistItem;
}

- (void)clearStatus
{
    [AJNotificationView hideCurrentNotificationViewAndClearQueue];
}

- (void)showStatus:(NSString *)status
{
    [self clearStatus];
    
    [AJNotificationView showNoticeInView:[[[UIApplication sharedApplication] delegate] window]
                                    type:AJNotificationTypeDefault
                                   title:status
                         linedBackground:AJLinedBackgroundTypeAnimated
                               hideAfter:0];
}

- (void)showErrorStatus:(NSString *)status
{
    [self clearStatus];
    
    [AJNotificationView showNoticeInView:[[[UIApplication sharedApplication] delegate] window]
                                    type:AJNotificationTypeRed
                                   title:status
                               hideAfter:10];
}

- (void)updatePlaybackProgress
{
    if (self.audioController.stream.continuous) {
        self.progressSlider.enabled = NO;
        self.progressSlider.value = 0;
       
    } else {
        self.progressSlider.enabled = YES;
        
        FSStreamPosition cur = self.audioController.stream.currentTimePlayed;
        FSStreamPosition end = self.audioController.stream.duration;
        [_progressSlider setMaximumValue: (end.minute*60)+end.second];
        [_progressSlider setValue:cur.playbackTimeInSeconds animated:YES];
        
        
    }
   
    
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
    
    [self resignFirstResponder];
    
    
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    // Free the resources (audio queue, etc.)
    _audioController = nil;
    
    if (_progressUpdateTimer) {
        [_progressUpdateTimer invalidate], _progressUpdateTimer = nil;
    }
}

@end
