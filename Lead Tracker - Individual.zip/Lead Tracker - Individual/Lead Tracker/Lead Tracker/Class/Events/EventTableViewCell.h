//
//  EventTableViewCell.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 23/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lbl_eventname;
@property (weak, nonatomic) IBOutlet UILabel *lbl_location;
@property (weak, nonatomic) IBOutlet UILabel *lbl_date;
@end
