//
//  AddEventViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 23/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DatePickerViewController.h"
@interface AddEventViewController : UIViewController<UITextFieldDelegate> {
    DatePickerViewController *datePicker;
}

- (IBAction)goBack:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *img_companyname;
@property (weak, nonatomic) IBOutlet UIImageView *img_location;
@property (weak, nonatomic) IBOutlet UIImageView *img_startdate;
@property (weak, nonatomic) IBOutlet UIImageView *img_enddate;
@property (weak, nonatomic) IBOutlet UITextField *txt_eventname;
@property (weak, nonatomic) IBOutlet UITextField *txt_location;
@property (weak, nonatomic) IBOutlet UITextField *txt_startdate;
@property (weak, nonatomic) IBOutlet UITextField *txt_enddate;
@property (assign, nonatomic) BOOL is_Edit;
@property (retain,nonatomic) NSMutableDictionary *eventDict;
- (IBAction)goAddevent:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UIButton *btn_add;
@end
