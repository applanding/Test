//
//  EventListViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 23/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "EventListViewController.h"

@interface EventListViewController ()

@end

@implementation EventListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _footerView = (DemoTableFooterView *) [[[NSBundle mainBundle] loadNibNamed:@"DemoTableFooterView" owner:self options:nil] objectAtIndex:0];
   
    _tableview.tableFooterView = _footerView;
    
    arr_upcomingoriginal = [[NSMutableArray alloc]init];
    arr_upcomingdisplay = [[NSMutableArray alloc]init];
   
    
    _tableview.hidden = YES;
     canLoadMore_upcoming = YES;
    if (Is_local){
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select * from events where is_active = 1 and is_deleted = 0 order by event_date desc LIMIT %d OFFSET 0 ",Limit] andCompletionBlock:^(FMResultSet *fresults){
            arr_upcomingoriginal = [[NSMutableArray alloc]init];
            arr_upcomingdisplay = [[NSMutableArray alloc]init];
            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];

            while ([fresults next]) {
                
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                NSDate *enddate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"end_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:enddate] forKey:@"enddate"];
                NSDate *eventdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"event_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:eventdate] forKey:@"startdate"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"location"]] forKey:@"location"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_name"]] forKey:@"name"];
                [arr_upcomingoriginal addObject:dict];
            }
             arr_upcomingdisplay = [[NSMutableArray alloc]initWithArray:arr_upcomingoriginal];
            if ([arr_upcomingoriginal count] < Limit) {
                canLoadMore_upcoming = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompletedupcoming];
            _tableview.hidden = NO;
        }];
    }
    else{
        [[ModelClass sharedInstance]eventlistwithparamter:
         @{@"userid":User_Id,
           @"start":@"0",
           @"limit":[NSString stringWithFormat:@"%d",Limit]
    }
    success:^(id result){
        
        if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
            arr_upcomingoriginal = [[NSMutableArray alloc]initWithArray:[result valueForKey:@"Event"]];
            arr_upcomingdisplay = [[NSMutableArray alloc]initWithArray:arr_upcomingoriginal];
            
            
        }else{
            [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
        }
        
        if ([arr_upcomingoriginal count] < Limit) {
            canLoadMore_upcoming = NO;
        }
        [_tableview reloadData];
        [self loadMoreCompletedupcoming];
        _tableview.hidden = NO;
    } error:^(NSError *error){
        canLoadMore_upcoming = NO;
    }];
    }
    _lbl_title.text = EventPlural;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
   
return [arr_upcomingdisplay count];
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
        static NSString *CellIdentifier = @"EventTableViewCell";
        EventTableViewCell *cell = (EventTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell==nil) {
            NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell= (EventTableViewCell *)[arrNib objectAtIndex:0];
            
        }
    
            cell.lbl_eventname.text = [NSString stringWithFormat:@"%@",[[arr_upcomingdisplay objectAtIndex:indexPath.row]valueForKey:@"name"]];
            cell.lbl_location.text = [NSString stringWithFormat:@"%@",[[arr_upcomingdisplay objectAtIndex:indexPath.row]valueForKey:@"location"]];
            cell.lbl_date.text = [NSString stringWithFormat:@"%@-%@",[[arr_upcomingdisplay objectAtIndex:indexPath.row]valueForKey:@"startdate"],[[arr_upcomingdisplay objectAtIndex:indexPath.row]valueForKey:@"enddate"]];
    
        return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.view endEditing:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    EventDetailViewController *godet = [[EventDetailViewController alloc]initWithNibName:@"EventDetailViewController" bundle:nil];
    godet.eventDict = [arr_upcomingdisplay objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:godet animated:YES];
}
- (IBAction)goBack:(id)sender {
    
    for (UIViewController *controller in [self.navigationController.viewControllers reverseObjectEnumerator]) {
        if ([controller isKindOfClass:[SearchViewController class]]) {
            [self.navigationController popToViewController:controller animated:YES];
            break;
        }
    }
}

- (IBAction)goAddEvent:(id)sender {
    AddEventViewController *goadd = [[AddEventViewController alloc]initWithNibName:@"AddEventViewController" bundle:nil];
    [self.navigationController pushViewController:goadd animated:YES];
}


-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
  
}
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    [arr_upcomingdisplay removeAllObjects];
   
    NSPredicate *p = [NSPredicate predicateWithFormat:@"SELF.name CONTAINS[cd] %@ or SELF.location CONTAINS[cd] %@ or SELF.startdate CONTAINS[cd] %@ or SELF.enddate CONTAINS[cd] %@", _txt_search.text, _txt_search.text, _txt_search.text,_txt_search.text];
    NSArray *arr = [arr_upcomingoriginal filteredArrayUsingPredicate:p];
    
    if ([_txt_search.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0) {
        [arr_upcomingdisplay removeAllObjects];
        [arr_upcomingdisplay addObjectsFromArray:arr];
        
        
    }else
    {
        [arr_upcomingdisplay addObjectsFromArray:arr_upcomingoriginal];
      
    }
    [_tableview reloadData];
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //    float endScrolling = scrollView.contentOffset.y + scrollView.frame.size.height;
    //    if (endScrolling >= scrollView.contentSize.height)
    //    {
    //        // your code goes here
    //    }
  
            if (!isLoadingMore_upcoming && canLoadMore_upcoming && _txt_search.text.length == 0) {
                CGFloat scrollPosition = scrollView.contentSize.height - scrollView.frame.size.height - scrollView.contentOffset.y;
                if (scrollPosition < [self footerLoadMoreHeight]) {
                    [self loadMoreupcoming];
                }
            }
}
- (CGFloat) footerLoadMoreHeight
{
    if (_footerView)
        return _footerView.frame.size.height;
    else
        return 52;
}
- (BOOL) loadMoreupcoming
{
    if (isLoadingMore_upcoming)
        return NO;
    
    [self willBeginLoadingMoreupcoming];
    isLoadingMore_upcoming = YES;
    return YES;
}

- (void) willBeginLoadingMoreupcoming
{
    
    [self.footerView.activityIndicator startAnimating];
    [self performSelector:@selector(addItemsOnBottomUpcoming) withObject:nil afterDelay:1.0];
}

-(void)addItemsOnBottomUpcoming{
    if (Is_local) {
     
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select * from events where is_active = 1 and is_deleted = 0 order by event_date desc LIMIT %d OFFSET %d ",Limit,(int)[arr_upcomingoriginal count]] andCompletionBlock:^(FMResultSet *fresults){
          
           
            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];
            int rescount = 0;
            while ([fresults next]) {
                rescount++;
               
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                NSDate *enddate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"end_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:enddate] forKey:@"enddate"];
                NSDate *eventdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"event_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:eventdate] forKey:@"startdate"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"location"]] forKey:@"location"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_name"]] forKey:@"name"];
                [arr_upcomingoriginal addObject:dict];
            }
            arr_upcomingdisplay = [[NSMutableArray alloc]initWithArray:arr_upcomingoriginal];
            if (rescount  < Limit) {
                canLoadMore_upcoming = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompletedupcoming];
        }];
        
    }else{
    [[ModelClass sharedInstance]eventlistwithparamter:
     @{@"userid":User_Id,
       @"start":[NSString stringWithFormat:@"%d",(int)[arr_upcomingoriginal count]],
       @"limit":[NSString stringWithFormat:@"%d",Limit]
       }
        success:^(id result){
                                                  
        if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
            [arr_upcomingoriginal addObjectsFromArray:[result valueForKey:@"Event"]];
            arr_upcomingdisplay = [[NSMutableArray alloc]initWithArray:arr_upcomingoriginal];
            
            [_tableview reloadData];
            if ([[result valueForKey:@"Event"]count] < Limit) {
                canLoadMore_upcoming = NO;
            }
           
        }else{
            canLoadMore_upcoming = NO;
        }
                                                  
        
            [self loadMoreCompletedupcoming];
        } error:^(NSError *error){
                canLoadMore_upcoming = NO;
                    }];
    }
}

- (void) loadMoreCompletedupcoming
{
    
    
    [self.footerView.activityIndicator stopAnimating];
    isLoadingMore_upcoming = NO;
    if (!canLoadMore_upcoming) {
        // Do something if there are no more items to load
        
        // We can hide the footerView by: [self setFooterViewVisibility:NO];
        
        // Just show a textual info that there are no more items to load
        self.footerView.infoLabel.hidden = NO;
    }
}

- (void) setFooterViewVisibility:(BOOL)visible
{
    if (visible && self.tableview.tableFooterView != _footerView)
        self.tableview.tableFooterView = _footerView;
    else if (!visible)
        self.tableview.tableFooterView = nil;
}

@end
