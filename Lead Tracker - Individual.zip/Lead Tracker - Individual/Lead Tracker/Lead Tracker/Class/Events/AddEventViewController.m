//
//  AddEventViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 23/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "AddEventViewController.h"

@interface AddEventViewController ()

@end

@implementation AddEventViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _img_companyname.layer.cornerRadius = 3.0;
    _img_location.layer.cornerRadius = 3.0;
    _img_startdate.layer.cornerRadius = 3.0;
    _img_enddate.layer.cornerRadius = 3.0;
    // Do any additional setup after loading the view from its nib.
    datePicker = [[DatePickerViewController alloc] initWithNibName:@"DatePickerViewController" bundle:nil];
    datePicker.delegate = self;
    
    if (_is_Edit) {
        _txt_eventname.text = [NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"name"]];
        _txt_location.text = [NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"location"]];
        _txt_startdate.text = [NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"startdate"]];
        _txt_enddate.text = [NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"enddate"]];
        _lbl_title.text = [NSString stringWithFormat:@"Edit %@",EventSingular];
        [_btn_add setTitle:@"Update" forState:UIControlStateNormal];
    }else{
        _lbl_title.text = [NSString stringWithFormat:@"Add %@",EventSingular];
    }
    _txt_eventname.placeholder = [NSString stringWithFormat:@"%@ Name",EventSingular];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
    if ([textField isEqual:_txt_startdate]) {
       
        [self presentSemiModalViewController:datePicker];
        datePicker.accessibilityHint = @"1";
        [self.view performSelector:@selector(endEditing:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.0];
       
        
    }
    if ([textField isEqual:_txt_enddate]) {
        
        if ([_txt_startdate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0) {
             [textField resignFirstResponder];
            [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter start date." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            return;
        }
         [self presentSemiModalViewController:datePicker];
        NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
        [_dateformat setDateFormat:@"MM/dd/yyyy"];
         [datePicker.picker setMinimumDate:[_dateformat dateFromString:_txt_startdate.text]];
        [datePicker.picker reloadInputViews];
        datePicker.accessibilityHint = @"2";
         [self.view performSelector:@selector(endEditing:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.0];
    }
    
}
-(void)pickerDone:(DatePickerViewController *)viewController {
    [self dismissSemiModalViewController:datePicker];
    
    NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];

    [_dateformat setDateFormat:@"MM/dd/yyyy"];
    
    if ([datePicker.accessibilityHint isEqualToString:@"1"]) {
        _txt_startdate.text = [NSString stringWithFormat:@"%@",[_dateformat stringFromDate:datePicker.picker.date]];
        _txt_enddate.text= @"";
    }else{
        _txt_enddate.text = [NSString stringWithFormat:@"%@",[_dateformat stringFromDate:datePicker.picker.date]];
    }
    
}
-(void)pickerCancel:(DatePickerViewController *)viewController{
    [self dismissSemiModalViewController:datePicker];
}
- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)goAddevent:(id)sender {
    [self.view endEditing:YES];
    
    if([_txt_eventname.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"Please enter %@ name.",EventSingular] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }else if([_txt_location.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter location." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    else if ([_txt_startdate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter start date." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }else if([_txt_enddate.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter end date." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    else{
        DELEGATE.is_refreshList = YES;
        if(Is_local){
            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];
            if (_is_Edit) {
                [[DatabaseHelper sharedInstance]executeUpdate:
                 [NSString stringWithFormat:@"Update events Set "
                  @"event_name = '%@', location= '%@',event_date= '%@',end_date= '%@',u_date= '%@' where id = '%@'"
                  ,
                  _txt_eventname.text,_txt_location.text,[NSString stringWithFormat:@"%d",(int)[[_dateformat dateFromString:_txt_startdate.text]timeIntervalSince1970]],[NSString stringWithFormat:@"%d",(int)[[_dateformat dateFromString:_txt_enddate.text]timeIntervalSince1970]],[NSString stringWithFormat:@"%d",(int)[[NSDate date]timeIntervalSince1970]],[_eventDict valueForKey:@"id"]] andCompletionBlock:^(BOOL success){
                     if (success) {
                         EventListViewController  *goevents = [[EventListViewController alloc]initWithNibName:@"EventListViewController" bundle:nil];
                         NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                         [vcs insertObject:goevents atIndex:[vcs count]-1];
                         [self.navigationController setViewControllers:vcs animated:NO];
                         [self.navigationController popViewControllerAnimated:YES];
                     }else{
                         [[[UIAlertView alloc] initWithTitle:@"" message:@"Please try again later" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                     }
                     
                 }];
            }else{
              
                [[DatabaseHelper sharedInstance]executeUpdate:
                 [NSString stringWithFormat:@"INSERT INTO events"
                                            @"(event_name, location,event_date,end_date,i_date)"
                                            @"VALUES('%@', '%@', '%@', '%@', '%@')",
                  _txt_eventname.text,_txt_location.text,[NSString stringWithFormat:@"%d",(int)[[_dateformat dateFromString:_txt_startdate.text]timeIntervalSince1970]],[NSString stringWithFormat:@"%d",(int)[[_dateformat dateFromString:_txt_enddate.text]timeIntervalSince1970]],[NSString stringWithFormat:@"%d",(int)[[NSDate date]timeIntervalSince1970]]] andCompletionBlock:^(BOOL success){
                if (success) {
                   
                    EventListViewController  *goevents = [[EventListViewController alloc]initWithNibName:@"EventListViewController" bundle:nil];
                    NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                    [vcs insertObject:goevents atIndex:[vcs count]-1];
                    [self.navigationController setViewControllers:vcs animated:NO];
                    [self.navigationController popViewControllerAnimated:YES];
                }else{
                  [[[UIAlertView alloc] initWithTitle:@"" message:@"Please try again later" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                }
            
            }];
            
            }
        }else{
        if (_is_Edit) {
            [[ModelClass sharedInstance]addorediteventwithparamter:
             @{@"userid":User_Id,
               @"eventid":[NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"id"]],
               @"event_name":[NSString stringWithFormat:@"%@",_txt_eventname.text],
               @"location":[NSString stringWithFormat:@"%@",_txt_location.text],
               @"sdate":[NSString stringWithFormat:@"%@",_txt_startdate.text],
               @"edate":[NSString stringWithFormat:@"%@",_txt_enddate.text]
               }
             success:^(id result){
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                EventListViewController  *goevents = [[EventListViewController alloc]initWithNibName:@"EventListViewController" bundle:nil];
                NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                [vcs insertObject:goevents atIndex:[vcs count]-1];
                [self.navigationController setViewControllers:vcs animated:NO];
                [self.navigationController popViewControllerAnimated:YES];
                }else{
                [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            }
                                                               
             } error:^(NSError *error){
                                                               
    }];
        }else{
        [[ModelClass sharedInstance]addorediteventwithparamter:
        @{@"userid":User_Id,
          @"event_name":[NSString stringWithFormat:@"%@",_txt_eventname.text],
          @"location":[NSString stringWithFormat:@"%@",_txt_location.text],
          @"sdate":[NSString stringWithFormat:@"%@",_txt_startdate.text],
          @"edate":[NSString stringWithFormat:@"%@",_txt_enddate.text]
          }
    
        success:^(id result){
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                EventListViewController  *goevents = [[EventListViewController alloc]initWithNibName:@"EventListViewController" bundle:nil];
                NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                [vcs insertObject:goevents atIndex:[vcs count]-1];
                [self.navigationController setViewControllers:vcs animated:NO];
                [self.navigationController popViewControllerAnimated:YES];
            }else{
                [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            }
                                                       
        } error:^(NSError *error){
    
    }];
        }
        }
   
    }
}
@end
