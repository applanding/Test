//
//  CommentTableViewCell.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 01/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "CommentTableViewCell.h"

@implementation CommentTableViewCell

- (void)awakeFromNib {
    // Initialization code
    
    [_sli_progress setThumbImage:[UIImage imageNamed:@"thumb"] forState:UIControlStateNormal];
    [_sli_progress setMinimumTrackImage:[[UIImage imageNamed:@"sliderprogress.png"]
                                  stretchableImageWithLeftCapWidth:5.0 topCapHeight:0.0] forState:UIControlStateNormal];
    
    [_sli_progress setMaximumTrackImage:[[UIImage imageNamed:@"sliderend.png"]
                                  stretchableImageWithLeftCapWidth:1.0 topCapHeight:0.0] forState:UIControlStateNormal];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
