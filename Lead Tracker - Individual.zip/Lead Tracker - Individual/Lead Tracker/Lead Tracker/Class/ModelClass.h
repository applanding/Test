//
//  ModelClass.h
//  APITest
//
//  Created by Evgeny Kalashnikov on 03.12.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "DarckWaitView.h"

@class DarckWaitView;
@class DarckWaitView_pad;
@interface ModelClass : NSObject {
  
    DarckWaitView *drkSignUp;

}

+ (ModelClass *)sharedInstance;
- (UIImage *)scaleAndRotateImage:(UIImage *)image;
- (BOOL) validateEmail: (NSString *)candidate;
- (void) doLoginwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void) doRegisterwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void) forgotPasswordwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)GetProfilewithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)updateProflewithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)eventlistwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)addorediteventwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)eventCommentlistwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)Leadlistwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)AddorEditLeadlistwithparamter:(NSDictionary *)parameters images:(NSMutableArray *)images success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)AddCommentwithparamter:(NSDictionary *)parameters is_audio:(BOOL)is_audio success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)LeadCommentlistwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)GetInfoTextwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)SearchEventLeadwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)GetEventLabel:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)SocialLoginwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)DeleteRecordwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
- (void)GetCommentCountwithparamter:(NSDictionary *)parameters success:(void (^)(id))result error:(void (^)(NSError *))error;
@end
