//
//  ViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 17/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, 560)];
    drkSignUp = [[DarckWaitView alloc] initWithDelegate:nil andInterval:0.1 andMathod:nil];
    // Do any additional setup after loading the view, typically from a nib.
    
//    FBLoginView *loginView =
//    [[FBLoginView alloc] initWithReadPermissions:
//     @[@"public_profile", @"email"]];
//    loginView.delegate = self;
//    loginView.center = self.view.center;
//    [self.view addSubview:loginView];
    
    _view_options.hidden = YES;
    _scrollview.hidden = YES;
    
    [FBLoginView class];
    _fbLogin.delegate = self;
    [_fbLogin setReadPermissions:@[@"public_profile", @"email"]];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(TapTerms)];
    [_lbl_terms addGestureRecognizer:tap];
    
}
// Call method when user information has been fetched
- (void)loginViewFetchedUserInfo:(FBLoginView *)loginView
                            user:(id<FBGraphUser>)user {
 //   NSLog(@"-->%@",user);
    
    [[ModelClass sharedInstance]SocialLoginwithparamter:@{@"type":@"F",
                                                          @"typeid":[NSString stringWithFormat:@"%@",[user objectForKey:@"id"]],
                                                          @"first_name":[NSString stringWithFormat:@"%@",[user objectForKey:@"first_name"]],
                                                          @"last_name":[NSString stringWithFormat:@"%@",[user objectForKey:@"last_name"]],
                                                          @"email":[NSString stringWithFormat:@"%@",[user objectForKey:@"email"]]
                                                         } success:^(id result){
                                                             if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                                                                 [[NSUserDefaults standardUserDefaults]setValue:[NSString stringWithFormat:@"%@",[result valueForKey:@"userid"]] forKey:@"userid"];
                                                                 [[NSUserDefaults standardUserDefaults]synchronize];
                                                                 
                                                                 SearchViewController  *gohome = [[SearchViewController alloc]initWithNibName:@"SearchViewController" bundle:nil];
                                                                 [self.navigationController pushViewController:gohome animated:YES];
                                                                 
                                                             }else{
                                                                 [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                                                             }
                                                         } error:^(NSError *error){
                                                         
                                                         }];
  
}
// Handle possible errors that can occur during login
- (void)loginView:(FBLoginView *)loginView handleError:(NSError *)error {
    NSString *alertMessage, *alertTitle;
    
    // If the user performs an action outside of you app to recover,
    // the SDK provides a message, you just need to surface it.
    // This handles cases like Facebook password change or unverified Facebook accounts.
    if ([FBErrorUtility shouldNotifyUserForError:error]) {
        alertTitle = @"Facebook error";
        alertMessage = [FBErrorUtility userMessageForError:error];
        
        // This code will handle session closures that happen outside of the app
        // You can take a look at our error handling guide to know more about it
        // https://developers.facebook.com/docs/ios/errors
    } else if ([FBErrorUtility errorCategoryForError:error] == FBErrorCategoryAuthenticationReopenSession) {
        alertTitle = @"Session Error";
        alertMessage = @"Your current session is no longer valid. Please log in again.";
        
        // If the user has cancelled a login, we will do nothing.
        // You can also choose to show the user a message if cancelling login will result in
        // the user not being able to complete a task they had initiated in your app
        // (like accessing FB-stored information or posting to Facebook)
    } else if ([FBErrorUtility errorCategoryForError:error] == FBErrorCategoryUserCancelled) {
        NSLog(@"user cancelled login");
        
        // For simplicity, this sample handles other errors with a generic message
        // You can checkout our error handling guide for more detailed information
        // https://developers.facebook.com/docs/ios/errors
    } else {
        alertTitle  = @"Something went wrong";
        alertMessage = @"Please try again later.";
        NSLog(@"Unexpected error:%@", error);
    }
    
    if (alertMessage) {
        [[[UIAlertView alloc] initWithTitle:alertTitle
                                    message:alertMessage
                                   delegate:nil
                          cancelButtonTitle:@"OK"
                          otherButtonTitles:nil] show];
    }
}
-(void)viewDidAppear:(BOOL)animated{
    if ((User_Id || Is_local)&&OptionSelected) {
        SearchViewController  *gohome = [[SearchViewController alloc]initWithNibName:@"SearchViewController" bundle:nil];
        [self.navigationController pushViewController:gohome animated:YES];
        return;
    }
    if (!OptionSelected) {
        _view_options.hidden = NO;
        _scrollview.hidden = YES;

    }else{
        _view_options.hidden = YES;
        _scrollview.hidden = NO;
    }
}
-(void)TapTerms{
    InfoViewController *goinfo = [[InfoViewController alloc]initWithNibName:@"InfoViewController" bundle:nil];
    goinfo.loadTerms = YES;
    [self.navigationController pushViewController:goinfo animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doLogin:(id)sender {
    [self.view endEditing:YES];
    if (![[ModelClass sharedInstance]validateEmail:[NSString stringWithFormat:@"%@",_txt_email.text]]) {
       [[[UIAlertView alloc] initWithTitle:@"" message:@"Your email address is not formatted correctly." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }else if([_txt_password.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter password." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    else{
        [[ModelClass sharedInstance]doLoginwithparamter:
         @{@"email":[NSString stringWithFormat:@"%@",_txt_email.text],
           @"password":[NSString stringWithFormat:@"%@",_txt_password.text]
           }
        success:^(id result){
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                [[NSUserDefaults standardUserDefaults]setValue:[NSString stringWithFormat:@"%@",[result valueForKey:@"userid"]] forKey:@"userid"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                SearchViewController  *gohome = [[SearchViewController alloc]initWithNibName:@"SearchViewController" bundle:nil];
                [self.navigationController pushViewController:gohome animated:YES];
                
            }else{
            [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            }
                                                    
        } error:^(NSError *error){
    
    }];
        
        
    }
}

- (IBAction)forgetPassword:(id)sender {
    forgetpass = [[UIAlertView alloc] initWithTitle:@"Please enter Email Address" message:@"" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK",nil];
    [forgetpass setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [forgetpass textFieldAtIndex:0].keyboardType=UIKeyboardTypeEmailAddress;
    [forgetpass textFieldAtIndex:0].keyboardAppearance = UIKeyboardAppearanceDefault;
    [forgetpass show];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if ([alertView isEqual:forgetpass]) {
        if (buttonIndex ==1) {
            [self performSelector:@selector(forgotpassapi) withObject:nil afterDelay:Delay_Time];
        }
    }
}
-(void)forgotpassapi{
    
[[ModelClass sharedInstance]forgotPasswordwithparamter:
    @{@"email":[NSString stringWithFormat:@"%@",[[forgetpass textFieldAtIndex:0] text]]}
                                               success:^(id result){
          [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
      }
        error:^(NSError *error){
    
}];
    
}
- (IBAction)goSignUp:(id)sender {
    RegisterViewController *goreg = [[RegisterViewController alloc]initWithNibName:@"RegisterViewController" bundle:nil];
    [self.navigationController pushViewController:goreg animated:YES];
}

- (IBAction)goSettings:(id)sender {
    SettingViewController *goset = [[SettingViewController alloc]initWithNibName:@"SettingViewController" bundle:nil];
    [self.navigationController pushViewController:goset animated:YES];
}

- (IBAction)goInfo:(id)sender {
    InfoViewController *goinfo = [[InfoViewController alloc]initWithNibName:@"InfoViewController" bundle:nil];
    [self.navigationController pushViewController:goinfo animated:YES];
}

- (IBAction)loginWithGoogle:(id)sender {
    [self.view endEditing:YES];
    
    
    GPPSignIn *signIn = [GPPSignIn sharedInstance];
    // You previously set kClientID in the "Initialize the Google+ client" step
    [drkSignUp showWithMessage:nil];
    signIn.clientID = GoogleClientID;
    signIn.scopes = [NSArray arrayWithObjects:
                     kGTLAuthScopePlusLogin, // defined in GTLPlusConstants.h
                     nil];
    signIn.shouldFetchGoogleUserEmail= YES;
    signIn.delegate = self;
    signIn.scopes = [NSArray arrayWithObjects:kGTLAuthScopePlusLogin,kGTLAuthScopePlusMe, nil];
    [[GPPSignIn sharedInstance] signOut];
    [[GPPSignIn sharedInstance] authenticate];

}
- (void)finishedWithAuth: (GTMOAuth2Authentication *)auth
                   error: (NSError *) error {
    if (error) {
        NSLog(@"Received error %@ and auth object %@",error, auth);
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Login Google Failed" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [drkSignUp hide];
        
    }else{
        GTLServicePlus* plusService = [[GTLServicePlus alloc] init];
        plusService.retryEnabled = YES;
        [plusService setAuthorizer:auth];
        GTLQueryPlus *query = [GTLQueryPlus queryForPeopleGetWithUserId:@"me"];
        [plusService executeQuery:query
                completionHandler:^(GTLServiceTicket *ticket,
                                    GTLPlusPerson *person,
                                    NSError *error) {
                    if (error) {
                        GTMLoggerError(@"Error: %@", error);
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Get Information Failed" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                        [alert show];
                        
                    } else {
                        
                        
                        [[ModelClass sharedInstance]SocialLoginwithparamter:
                         @{@"type":@"G",
                        @"typeid":[NSString stringWithFormat:@"%@",person.identifier],
                        @"first_name":[NSString stringWithFormat:@"%@",person.name.givenName],
                        @"last_name":[NSString stringWithFormat:@"%@",person.name.familyName],
                        @"email":[NSString stringWithFormat:@"%@",[GPPSignIn sharedInstance].authentication.userEmail]
                        } success:^(id result){
                            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                                [[NSUserDefaults standardUserDefaults]setValue:[NSString stringWithFormat:@"%@",[result valueForKey:@"userid"]] forKey:@"userid"];
                                [[NSUserDefaults standardUserDefaults]synchronize];
                                
                                SearchViewController  *gohome = [[SearchViewController alloc]initWithNibName:@"SearchViewController" bundle:nil];
                                [self.navigationController pushViewController:gohome animated:YES];
                                
                            }else{
                                [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                            }
                        } error:^(NSError *error){
                            
                        }];
                    }
                    [drkSignUp hide];
                
                }];
        
    }
    
}

- (IBAction)selectCloud:(id)sender {
    [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"OptionSelected"];
    [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"is_local"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    _view_options.hidden = YES;
    _scrollview.hidden = NO;
}

- (IBAction)selectLocal:(id)sender {
    [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"OptionSelected"];
    [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"is_local"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    SearchViewController  *gohome = [[SearchViewController alloc]initWithNibName:@"SearchViewController" bundle:nil];
    [self.navigationController pushViewController:gohome animated:YES];
}
@end
