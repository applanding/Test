//
//  InfoViewController.m
//  LeadTalks
//
//  Created by Applanding Solutions on 19/01/15.
//  Copyright (c) 2015 Applanding Solutions. All rights reserved.
//

#import "InfoViewController.h"

@interface InfoViewController ()

@end

@implementation InfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
//    [[ModelClass sharedInstance]GetInfoTextwithparamter:@{@"pagename":@"Help/FAQ"}
//success:^(id result){
//    if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
//        [_webview loadHTMLString:[NSString stringWithFormat:@"%@",[result valueForKey:@"content"]] baseURL:nil];
//    }else{
//        [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
//    }
//} error:^(NSError *error){
//
//}];
    
    if (_loadTerms) {
        [_webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/terms-and-conditions",[[NSUserDefaults standardUserDefaults]valueForKey:@"SavedURL"]]]]];
        _lbl_title.text = @"T & C";
    }else{
        [_webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/faq",[[NSUserDefaults standardUserDefaults]valueForKey:@"SavedURL"]]]]];
        _lbl_title.text = @"Help/FAQ";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    return YES;
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}
-(void)webViewDidFinishLoad:(UIWebView *)webView{
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
