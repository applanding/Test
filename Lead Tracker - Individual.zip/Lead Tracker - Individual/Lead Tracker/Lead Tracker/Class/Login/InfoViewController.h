//
//  InfoViewController.h
//  LeadTalks
//
//  Created by Applanding Solutions on 19/01/15.
//  Copyright (c) 2015 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *webview;
- (IBAction)goBack:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (assign,nonatomic) BOOL loadTerms;
@end
