//
//  RegisterViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 21/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController<UIAlertViewDelegate>
{
    UIAlertView *logout;
}
- (IBAction)goBack:(id)sender;

@property (weak, nonatomic) IBOutlet UITextField *txt_firstname;
@property (weak, nonatomic) IBOutlet UITextField *txt_lastname;
@property (weak, nonatomic) IBOutlet UITextField *txt_email;
@property (weak, nonatomic) IBOutlet UITextField *txt_password;
@property (assign, nonatomic) BOOL is_update;
- (IBAction)goJoin:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UIButton *btn_join;
@property (weak, nonatomic) IBOutlet UIButton *btn_logout;
- (IBAction)goInfo:(id)sender;

- (IBAction)goLogout:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_terms;
@end
