//
//  ViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 17/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ModelClass.h"
#import "RegisterViewController.h"
#import "EventListViewController.h"
#import "SettingViewController.h"
#import "InfoViewController.h"
#import <FacebookSDK/FacebookSDK.h>
#import <GooglePlus/GooglePlus.h>
#import <GoogleOpenSource/GoogleOpenSource.h>
#import "DarckWaitView.h"
@interface ViewController : UIViewController<UIAlertViewDelegate,FBLoginViewDelegate,GPPSignInDelegate>{
    UIAlertView *forgetpass;
     DarckWaitView *drkSignUp;
}


@property (weak, nonatomic) IBOutlet UIView *view_options;
- (IBAction)selectCloud:(id)sender;
- (IBAction)selectLocal:(id)sender;

@property (weak, nonatomic) IBOutlet FBLoginView *fbLogin;
@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollview;
@property (weak, nonatomic) IBOutlet UITextField *txt_email;
@property (weak, nonatomic) IBOutlet UITextField *txt_password;
- (IBAction)doLogin:(id)sender;
- (IBAction)forgetPassword:(id)sender;
- (IBAction)goSignUp:(id)sender;
- (IBAction)goSettings:(id)sender;
- (IBAction)goInfo:(id)sender;
- (IBAction)loginWithGoogle:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_terms;
@end

