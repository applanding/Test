//
//  SettingViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 16/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController<UITextFieldDelegate>
- (IBAction)goBack:(id)sender;

- (IBAction)goSave:(id)sender;
- (IBAction)goReset:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *img_txtbg;
@property (weak, nonatomic) IBOutlet UITextField *txt_url;
@end
