//
//  SettingViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 16/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "SettingViewController.h"

@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _txt_url.text = [NSString stringWithFormat:@"%@",[[NSUserDefaults standardUserDefaults]valueForKey:@"SavedURL"]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)goSave:(id)sender {
    [self.view endEditing:YES];
    if([_txt_url.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter URL." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }else{
        [self.view endEditing:YES];
        [[NSUserDefaults standardUserDefaults]setValue:[NSString stringWithFormat:@"%@",_txt_url.text] forKey:@"SavedURL"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Saved Successfully." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
}

- (IBAction)goReset:(id)sender {
    [self.view endEditing:YES];
     _txt_url.text = [NSString stringWithFormat:@"%@",DEFAULT_URL];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

@end
