//
//  RegisterViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 21/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (_is_update) {
        _lbl_terms.hidden = YES;
        _btn_logout.hidden = NO;
        _lbl_title.text = @"My Profile";
        [_btn_join setTitle:@"Update" forState:UIControlStateNormal];
        [[ModelClass sharedInstance]GetProfilewithparamter:@{@"userid":User_Id}
    success:^(id result){
        if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
            _txt_email.text = [NSString stringWithFormat:@"%@",[result valueForKey:@"email"]];
            _txt_firstname.text = [NSString stringWithFormat:@"%@",[result valueForKey:@"firstname"]];
            _txt_lastname.text = [NSString stringWithFormat:@"%@",[result valueForKey:@"lastname"]];
        }else{
            [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
        }
    } error:^(NSError *error){
    
    }];
    }else{
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(TapTerms)];
        [_lbl_terms addGestureRecognizer:tap];
        _btn_logout.hidden = YES;
        _lbl_title.text = @"Register";
         [_btn_join setTitle:@"Join" forState:UIControlStateNormal];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)TapTerms{
    InfoViewController *goinfo = [[InfoViewController alloc]initWithNibName:@"InfoViewController" bundle:nil];
    goinfo.loadTerms = YES;
    [self.navigationController pushViewController:goinfo animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)goJoin:(id)sender {
    [self.view endEditing:YES];
    
    if([_txt_firstname.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter first name." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }else if([_txt_lastname.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter last name." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    else if (![[ModelClass sharedInstance]validateEmail:[NSString stringWithFormat:@"%@",_txt_email.text]]) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Your email address is not formatted correctly." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }else if([_txt_password.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 && !_is_update) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter password." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    else{
        if (_is_update) {
            [[ModelClass sharedInstance]updateProflewithparamter:
             @{@"first_name":[NSString stringWithFormat:@"%@",_txt_firstname.text],
               @"last_name":[NSString stringWithFormat:@"%@",_txt_lastname.text],
               @"email":[NSString stringWithFormat:@"%@",_txt_email.text],
               @"password":[NSString stringWithFormat:@"%@",_txt_password.text],
               @"userid":User_Id
               }
            success:^(id result){
           
                [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            } error:^(NSError *error){
                                                           
            }];
        }else{
        [[ModelClass sharedInstance]doRegisterwithparamter:
         @{@"first_name":[NSString stringWithFormat:@"%@",_txt_firstname.text],
           @"last_name":[NSString stringWithFormat:@"%@",_txt_lastname.text],
           @"email":[NSString stringWithFormat:@"%@",_txt_email.text],
           @"password":[NSString stringWithFormat:@"%@",_txt_password.text]
           }
            success:^(id result){
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                [[NSUserDefaults standardUserDefaults]setValue:[NSString stringWithFormat:@"%@",[result valueForKey:@"userid"]] forKey:@"userid"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                SearchViewController  *gohome = [[SearchViewController alloc]initWithNibName:@"SearchViewController" bundle:nil];
                [self.navigationController pushViewController:gohome animated:YES];
            }else{
            [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            }
                                                        
                } error:^(NSError *error){
                                                        
        }];
        }
    }
}
- (IBAction)goInfo:(id)sender {
    InfoViewController *goinfo = [[InfoViewController alloc]initWithNibName:@"InfoViewController" bundle:nil];
    [self.navigationController pushViewController:goinfo animated:YES];
}

- (IBAction)goLogout:(id)sender {
    logout = [[UIAlertView alloc]initWithTitle:@"" message:@"Are you sure to logout?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Yes", nil];
    [logout show];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if ([alertView isEqual:logout] && buttonIndex == 1) {
        [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"userid"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        ViewController *goLogin = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
        [self.navigationController pushViewController:goLogin animated:YES];
        
        FBSession* session = [FBSession activeSession];
        [session closeAndClearTokenInformation];
        [session close];
        [FBSession setActiveSession:nil];
        
        NSHTTPCookieStorage* cookies = [NSHTTPCookieStorage sharedHTTPCookieStorage];
        NSArray* facebookCookies = [cookies cookiesForURL:[NSURL         URLWithString:@"https://facebook.com/"]];
        
        for (NSHTTPCookie* cookie in facebookCookies) {
            [cookies deleteCookie:cookie];
        }
        
        [[GPPSignIn sharedInstance] signOut];

    }
}
@end
