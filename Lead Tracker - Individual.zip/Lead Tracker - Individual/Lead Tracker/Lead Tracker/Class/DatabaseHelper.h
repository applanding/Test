//
//  DatabaseHelper.h
//  TenderTiger
//
//  Created by ETL on 17/11/14.
//  Copyright (c) 2014 ETL. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "FMDB.h"

@interface DatabaseHelper : NSObject

@property(strong,nonatomic) FMDatabase *db;
@property(strong,nonatomic) FMDatabaseQueue *queue;
+ (DatabaseHelper *)sharedInstance;
-(void)checkAndCreateTables;
- (void) openDB;
- (void) closeDB;
-(void)executeQuery:(NSString *)Query andCompletionBlock:(void(^)(FMResultSet *fResult))completionBlock;
- (void) executeUpdate:(NSString*)Query andCompletionBlock:(void(^)(BOOL success))completionBlock;
@end
