//
//  AppDelegate.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 17/11/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "AFNetworkActivityIndicatorManager.h"
#import <FacebookSDK/FacebookSDK.h>
#import <GooglePlus/GooglePlus.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (assign, nonatomic) BOOL is_refresh;
@property (assign, nonatomic) BOOL is_refreshList;
-(NSString *) getRandomString;

@end

