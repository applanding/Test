//
//  SearchViewController.m
//  LeadTalks
//
//  Created by Applanding Solutions on 04/02/15.
//  Copyright (c) 2015 Applanding Solutions. All rights reserved.
//

#import "SearchViewController.h"

@interface SearchViewController ()

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _footerView = (DemoTableFooterView *) [[[NSBundle mainBundle] loadNibNamed:@"DemoTableFooterView" owner:self options:nil] objectAtIndex:0];
    
    _tableview.tableFooterView = _footerView;
    canLoadMore = YES;
    iseventmore = NO;
    isleadmore = NO;
    
    if (Is_local) {
        _btn_profile.hidden = YES;
    }
    
    displayarr = [[NSMutableArray alloc]init];
    eventarr = [[NSMutableArray alloc]init];
    leadarr = [[NSMutableArray alloc]init];
    
    [self CallFirstTimeAPI];
}
-(void)CallFirstTimeAPI{
   _txt_search.text = @"";
    if(Is_local){
       leadcount = 0;
        eventcount = 0;
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select * from events where is_active = 1 and is_deleted = 0 order by event_date desc LIMIT %d OFFSET 0 ",Limit] andCompletionBlock:^(FMResultSet *fresults){
            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];
            [eventarr removeAllObjects];
            while ([fresults next]) {
                eventcount++;
              
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                NSDate *enddate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"end_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:enddate] forKey:@"enddate"];
                NSDate *eventdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"event_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:eventdate] forKey:@"startdate"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"location"]] forKey:@"location"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_name"]] forKey:@"name"];
                [eventarr addObject:dict];
            }
            
        }];
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select leads.*,events.end_date,events.event_date,events.location,events.event_name from leads inner join events on leads.event_id = events.id  where leads.is_active = 1 and leads.is_deleted = 0 order by leads.i_date desc LIMIT %d OFFSET 0 ",Limit] andCompletionBlock:^(FMResultSet *fresults){
            [leadarr removeAllObjects];
            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];
            while ([fresults next]) {
                leadcount++;
              
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"card_image"]] forKey:@"card"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"company"]] forKey:@"company"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"email"]] forKey:@"email"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"pic_image"]] forKey:@"image"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"phone"]] forKey:@"phone"];
                NSMutableDictionary *dict1 = [NSMutableDictionary dictionary];
                NSDate *enddate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"end_date"]intValue]];
                [dict1 setObject:[_dateformat stringFromDate:enddate] forKey:@"enddate"];
                NSDate *eventdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"event_date"]intValue]];
                [dict1 setObject:[_dateformat stringFromDate:eventdate] forKey:@"startdate"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_id"]] forKey:@"id"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"location"]] forKey:@"location"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_name"]] forKey:@"name"];
                [dict setObject:dict1 forKey:@"event"];
                [leadarr addObject:dict];
            }
            [self displaydata];
            
            
            
        }];
        
        
        
    }else{
    
    [[ModelClass sharedInstance]SearchEventLeadwithparamter:
     @{@"userid":User_Id,
       @"search":@"",
       @"start":@"0",
       @"limit":[NSString stringWithFormat:@"%d",Limit]
       } success:^(id result){
           [displayarr removeAllObjects];
           [eventarr removeAllObjects];
           [leadarr removeAllObjects];
           if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
               [eventarr addObjectsFromArray:[result valueForKey:@"Event"]];
               [leadarr addObjectsFromArray:[result valueForKey:@"Lead"]];
               
               if ([[result valueForKey:@"eventloadmore"]isEqualToString:@"N"]) {
                   iseventmore = NO;
               }else{
                   iseventmore = YES;
               }
               if ([[result valueForKey:@"leadloadmore"]isEqualToString:@"N"]) {
                   isleadmore = NO;
               }else{
                   isleadmore = YES;
               }
               
               if (_segment.selectedSegmentIndex == 1) {
                   canLoadMore = iseventmore;
                   [displayarr addObjectsFromArray:eventarr];
               }else{
                   canLoadMore = isleadmore;
                   [displayarr addObjectsFromArray:leadarr];
                   
               }
               
               
           }
          // canLoadMore = NO;
           [self loadMoreCompleted];
           [_tableview reloadData];
           
       } error:^(NSError *error){
           
       }];
    }
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    if (DELEGATE.is_refreshList) {
        DELEGATE.is_refreshList = NO;
        [self CallFirstTimeAPI];
    }
    [_segment setTitle:EventPlural forSegmentAtIndex:1];
    [_segment setTitle:LeadPlural forSegmentAtIndex:0];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)displaydata{
    [displayarr removeAllObjects];
    if (eventcount <Limit) {
        iseventmore = NO;
    }else{
        iseventmore = YES;
    }
    if (leadcount < Limit) {
        isleadmore = NO;
    }else{
        isleadmore = YES;
    }
 
    if (_segment.selectedSegmentIndex == 1) {
        canLoadMore = iseventmore;
        [displayarr addObjectsFromArray:eventarr];
    }else{
         canLoadMore = isleadmore;
        [displayarr addObjectsFromArray:leadarr];
        
    }
  //  canLoadMore = NO;
    [self loadMoreCompleted];
    [_tableview reloadData];
}
-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return [displayarr count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"EventTableViewCell";
    EventTableViewCell *cell = (EventTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell= (EventTableViewCell *)[arrNib objectAtIndex:0];
        
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    
    switch (_segment.selectedSegmentIndex) {
        case 1:
        {
            static NSString *CellIdentifier = @"EventTableViewCell";
            EventTableViewCell *cell = (EventTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell==nil) {
                NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
                cell= (EventTableViewCell *)[arrNib objectAtIndex:0];
                
            }
             [cell setBackgroundColor:[UIColor clearColor]];
            cell.lbl_eventname.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"name"]];
            cell.lbl_location.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"location"]];
            cell.lbl_date.text = [NSString stringWithFormat:@"%@-%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"startdate"],[[displayarr objectAtIndex:indexPath.row]valueForKey:@"enddate"]];
            return cell;
            break;
        }
        case 0:
        {
            static NSString *CellIdentifier = @"LeadTableViewCell";
            LeadTableViewCell *cell = (LeadTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell==nil) {
                NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
                cell= (LeadTableViewCell *)[arrNib objectAtIndex:0];
                
            }    cell.selectionStyle=UITableViewCellSelectionStyleNone;
             [cell setBackgroundColor:[UIColor clearColor]];
            
            cell.lbl_name.text = [NSString stringWithFormat:@"%@ %@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"firstname"],[[displayarr objectAtIndex:indexPath.row]valueForKey:@"lastname"]];
            cell.lbl_email.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"email"]];
            cell.lbl_phonenum.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"phone"]];
      //      [cell.img_profile setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",Img_Path,[[displayarr objectAtIndex:indexPath.row]valueForKey:@"image"]]] placeholderImage:[UIImage imageNamed:@"placeholder_user"]];
            if ([[[displayarr objectAtIndex:indexPath.row]valueForKey:@"image"] rangeOfString:@"img_"].location == NSNotFound) {
                [cell.img_profile setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",Img_Path,[[displayarr objectAtIndex:indexPath.row]valueForKey:@"image"]]] placeholderImage:[UIImage imageNamed:@"placeholder_user"]];
            }else{
                
                cell.img_profile.image = [UIImage imageWithContentsOfFile:[Document_Directory stringByAppendingPathComponent:[[displayarr objectAtIndex:indexPath.row]valueForKey:@"image"]]];
                
            }
            
            
            return cell;
            break;
        }
        default:
            break;
    }
    return cell;
   
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self.view endEditing:YES];
    switch (_segment.selectedSegmentIndex) {
        case 1:
        {
            EventDetailViewController *godet = [[EventDetailViewController alloc]initWithNibName:@"EventDetailViewController" bundle:nil];
           godet.eventDict = [displayarr objectAtIndex:indexPath.row];
            [self.navigationController pushViewController:godet animated:YES];
             break;
        }
        case 0:
            {
                LeadDetailViewController *goLead = [[LeadDetailViewController alloc]initWithNibName:@"LeadDetailViewController" bundle:nil];
                goLead.eventDict = [[displayarr objectAtIndex:indexPath.row]valueForKey:@"event"];
                goLead.leadDict = [displayarr objectAtIndex:indexPath.row];
                [self.navigationController pushViewController:goLead animated:YES];
                 break;
            }
        default:
            break;
        }
    
    
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //    float endScrolling = scrollView.contentOffset.y + scrollView.frame.size.height;
    //    if (endScrolling >= scrollView.contentSize.height)
    //    {
    //        // your code goes here
    //    }
    
    if (!isLoadingMore && canLoadMore) {
        CGFloat scrollPosition = scrollView.contentSize.height - scrollView.frame.size.height - scrollView.contentOffset.y;
        if (scrollPosition < [self footerLoadMoreHeight]) {
            [self loadMore];
        }
    }
}
- (CGFloat) footerLoadMoreHeight
{
    if (_footerView)
        return _footerView.frame.size.height;
    else
        return 52;
}
- (BOOL) loadMore
{
    if (isLoadingMore)
        return NO;
    
    [self willBeginLoadingMore];
    isLoadingMore = YES;
    return YES;
}
- (void) willBeginLoadingMore
{
    if ([_txt_search.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0) {
      //  return;
    }
    [self.footerView.activityIndicator startAnimating];
    [self performSelector:@selector(addItemsOnBottom) withObject:nil afterDelay:1.0];
}
-(void)addItemsOnBottom{
    
    if(Is_local){
        leadcount = 0;
        eventcount = 0;
        NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
        [_dateformat setDateFormat:@"MM/dd/yyyy"];
        int time = (int)[_dateformat dateFromString:_txt_search.text];
        NSString *searchTime = @" ";
        if (time > 0) {
            searchTime = [NSString stringWithFormat:@"%d",time];
        }
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select * from events where is_active = 1 and is_deleted = 0 and(event_name like '%%%@%%' or location like '%%%@%%' or event_date like '%%%@%%' or end_date like '%%%@%%') order by event_date desc LIMIT %d OFFSET %d ", _txt_search.text,_txt_search.text,searchTime,searchTime,Limit,(int)[displayarr count]] andCompletionBlock:^(FMResultSet *fresults){
           
           
            while ([fresults next]) {
                eventcount++;
                
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                NSDate *enddate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"end_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:enddate] forKey:@"enddate"];
                NSDate *eventdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"event_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:eventdate] forKey:@"startdate"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"location"]] forKey:@"location"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_name"]] forKey:@"name"];
                [eventarr addObject:dict];
            }
            
        }];
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select leads.*,events.end_date,events.event_date,events.location,events.event_name from leads inner join events on leads.event_id = events.id  where leads.is_active = 1 and leads.is_deleted = 0 and (company like '%%%@%%' or first_name ||\" \" || last_name like '%%%@%%' or email like '%%%@%%' or phone like '%%%@%%' )order by leads.i_date desc LIMIT %d OFFSET %d ",_txt_search.text,_txt_search.text,_txt_search.text,_txt_search.text,Limit,(int)[displayarr count]] andCompletionBlock:^(FMResultSet *fresults){
            while ([fresults next]) {
                leadcount++;
              
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"card_image"]] forKey:@"card"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"company"]] forKey:@"company"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"email"]] forKey:@"email"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"pic_image"]] forKey:@"image"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"phone"]] forKey:@"phone"];
                NSMutableDictionary *dict1 = [NSMutableDictionary dictionary];
                NSDate *enddate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"end_date"]intValue]];
                [dict1 setObject:[_dateformat stringFromDate:enddate] forKey:@"enddate"];
                NSDate *eventdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"event_date"]intValue]];
                [dict1 setObject:[_dateformat stringFromDate:eventdate] forKey:@"startdate"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_id"]] forKey:@"id"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"location"]] forKey:@"location"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_name"]] forKey:@"name"];
                [dict setObject:dict1 forKey:@"event"];
                [leadarr addObject:dict];
            }
            [self displaydata];
            
            
            
        }];
        
        
        
    }else{
    [[ModelClass sharedInstance]SearchEventLeadwithparamter:
     @{@"userid":User_Id,
       @"search":[NSString stringWithFormat:@"%@",_txt_search.text],
       @"start":[NSString stringWithFormat:@"%d",(int)[displayarr count]],
       @"limit":[NSString stringWithFormat:@"%d",Limit]
       } success:^(id result){
           
           [displayarr removeAllObjects];
           if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
               [eventarr addObjectsFromArray:[result valueForKey:@"Event"]];
               [leadarr addObjectsFromArray:[result valueForKey:@"Lead"]];
               
               if ([[result valueForKey:@"eventloadmore"]isEqualToString:@"N"]) {
                   iseventmore = NO;
               }else{
                   iseventmore = YES;
               }
               if ([[result valueForKey:@"leadloadmore"]isEqualToString:@"N"]) {
                   isleadmore = NO;
               }else{
                   isleadmore = YES;
               }
               
               if (_segment.selectedSegmentIndex == 1) {
                   canLoadMore = iseventmore;
                   [displayarr addObjectsFromArray:eventarr];
               }else{
                   canLoadMore = isleadmore;
                   [displayarr addObjectsFromArray:leadarr];
                   
               }
           }
           
           
           [_tableview reloadData];
           [self loadMoreCompleted];
       } error:^(NSError *error){
           
       }];
    }
}
- (void) loadMoreCompleted
{
    
    
    [self.footerView.activityIndicator stopAnimating];
    isLoadingMore = NO;
    if (!canLoadMore) {
        // Do something if there are no more items to load
        
        // We can hide the footerView by: [self setFooterViewVisibility:NO];
        
        // Just show a textual info that there are no more items to load
        self.footerView.infoLabel.hidden = NO;
    }else{
        self.footerView.infoLabel.hidden = YES;
    }
}
- (void) setFooterViewVisibility:(BOOL)visible
{
    if (visible && self.tableview.tableFooterView != _footerView)
        self.tableview.tableFooterView = _footerView;
    else if (!visible)
        self.tableview.tableFooterView = nil;
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
    [self.view endEditing:YES];
    if ([_txt_search.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0) {
        return;
    }if(Is_local){
        [displayarr removeAllObjects];
        [eventarr removeAllObjects];
        [leadarr removeAllObjects];
        leadcount = 0;
        eventcount = 0;
        NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
        [_dateformat setDateFormat:@"MM/dd/yyyy"];
        int time = (int)[_dateformat dateFromString:_txt_search.text];
        NSString *searchTime = @" ";
        if (time > 0) {
            searchTime = [NSString stringWithFormat:@"%d",time];
        }
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select * from events where is_active = 1 and is_deleted = 0 and(event_name like '%%%@%%' or location like '%%%@%%' or event_date like '%%%@%%' or end_date like '%%%@%%') order by event_date desc LIMIT %d OFFSET 0 ", _txt_search.text,_txt_search.text,searchTime,searchTime,Limit] andCompletionBlock:^(FMResultSet *fresults){
            while ([fresults next]) {
                eventcount++;
                
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                NSDate *enddate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"end_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:enddate] forKey:@"enddate"];
                NSDate *eventdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"event_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:eventdate] forKey:@"startdate"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"location"]] forKey:@"location"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_name"]] forKey:@"name"];
                [eventarr addObject:dict];
            }
            
        }];
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select leads.*,events.end_date,events.event_date,events.location,events.event_name from leads inner join events on leads.event_id = events.id  where leads.is_active = 1 and leads.is_deleted = 0 and (company like '%%%@%%' or first_name ||\" \" || last_name like '%%%@%%' or email like '%%%@%%' or phone like '%%%@%%' )order by leads.i_date desc LIMIT %d OFFSET 0 ",_txt_search.text,_txt_search.text,_txt_search.text,_txt_search.text,Limit] andCompletionBlock:^(FMResultSet *fresults){
           
            while ([fresults next]) {
                leadcount++;
                
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"card_image"]] forKey:@"card"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"company"]] forKey:@"company"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"email"]] forKey:@"email"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"pic_image"]] forKey:@"image"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"phone"]] forKey:@"phone"];
                NSMutableDictionary *dict1 = [NSMutableDictionary dictionary];
                NSDate *enddate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"end_date"]intValue]];
                [dict1 setObject:[_dateformat stringFromDate:enddate] forKey:@"enddate"];
                NSDate *eventdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"event_date"]intValue]];
                [dict1 setObject:[_dateformat stringFromDate:eventdate] forKey:@"startdate"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_id"]] forKey:@"id"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"location"]] forKey:@"location"];
                [dict1 setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"event_name"]] forKey:@"name"];
                [dict setObject:dict1 forKey:@"event"];
                [leadarr addObject:dict];
            }
            [self displaydata];

           
            
        }];
    }else{
    [[ModelClass sharedInstance]SearchEventLeadwithparamter:
    @{@"userid":User_Id,
      @"search":[NSString stringWithFormat:@"%@",searchBar.text],
      @"start":@"0",
      @"limit":[NSString stringWithFormat:@"%d",Limit]
      } success:^(id result){
           [displayarr removeAllObjects];
          [eventarr removeAllObjects];
          [leadarr removeAllObjects];
          if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
              [eventarr addObjectsFromArray:[result valueForKey:@"Event"]];
              [leadarr addObjectsFromArray:[result valueForKey:@"Lead"]];
              
              if ([[result valueForKey:@"eventloadmore"]isEqualToString:@"N"]) {
                  iseventmore = NO;
              }else{
                  iseventmore = YES;
              }
              if ([[result valueForKey:@"leadloadmore"]isEqualToString:@"N"]) {
                  isleadmore = NO;
              }else{
                  isleadmore = YES;
              }

              if (_segment.selectedSegmentIndex == 1) {
                  canLoadMore = iseventmore;
                  [displayarr addObjectsFromArray:eventarr];
              }else{
                  canLoadMore = isleadmore;
                  [displayarr addObjectsFromArray:leadarr];

              }
          }
          [self loadMoreCompleted];
           [_tableview reloadData];
       
      } error:^(NSError *error){
      
      }];
    }
    
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    
    // The user clicked the [X] button or otherwise cleared the text.
    if([searchText length] == 0) {
        [searchBar performSelector: @selector(resignFirstResponder)
                        withObject: nil
                        afterDelay: 0.1];
        [self CallFirstTimeAPI]; // or whatever
    }
}
- (IBAction)SegmentClicked:(UISegmentedControl *)sender{
    [displayarr removeAllObjects];
    if (sender.selectedSegmentIndex ==1) {
        canLoadMore = iseventmore;
        [displayarr addObjectsFromArray:eventarr];
    }else{
        canLoadMore = isleadmore;
        [displayarr addObjectsFromArray:leadarr];
    }
    [_tableview reloadData];
    [self loadMoreCompleted];

}

- (IBAction)goEvent:(id)sender {
    EventListViewController  *goevents = [[EventListViewController alloc]initWithNibName:@"EventListViewController" bundle:nil];
    [self.navigationController pushViewController:goevents animated:YES];
}
- (IBAction)goProfile:(id)sender {
    RegisterViewController *goreg = [[RegisterViewController alloc]initWithNibName:@"RegisterViewController" bundle:nil];
    goreg.is_update = YES;
    [self.navigationController pushViewController:goreg animated:YES];
}
@end
