//
//  SearchViewController.h
//  LeadTalks
//
//  Created by Applanding Solutions on 04/02/15.
//  Copyright (c) 2015 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController <UITableViewDataSource, UITableViewDelegate,UISearchBarDelegate>
{
    NSMutableArray *eventarr;
    NSMutableArray *leadarr;
    NSMutableArray *displayarr;
    BOOL isLoadingMore;
    BOOL canLoadMore;
    BOOL iseventmore;
    BOOL isleadmore;
    int eventcount;
    int leadcount;
}
@property (weak, nonatomic) IBOutlet UIButton *btn_profile;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;
- (IBAction)goProfile:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UISearchBar *txt_search;
@property (nonatomic, retain) DemoTableFooterView *footerView;
- (IBAction)SegmentClicked:(id)sender;
- (IBAction)goEvent:(id)sender;
@end
