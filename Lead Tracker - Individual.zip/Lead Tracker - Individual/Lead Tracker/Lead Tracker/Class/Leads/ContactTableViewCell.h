//
//  ContactTableViewCell.h
//  TenderTiger
//
//  Created by ETL on 03/12/14.
//  Copyright (c) 2014 ETL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactTableViewCell : UITableViewCell

@end
