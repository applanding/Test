//
//  AddLeadViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 07/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "AddLeadViewController.h"

@interface AddLeadViewController ()

@end

@implementation AddLeadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _btn_card.imageView.contentMode = UIViewContentModeScaleAspectFill;
    _btn_profilepic.imageView.contentMode = UIViewContentModeScaleAspectFill;

    _img_firstname.layer.cornerRadius = 3.0;
    _img_lastname.layer.cornerRadius = 3.0;
    _img_email.layer.cornerRadius = 3.0;
    _img_phonenum.layer.cornerRadius = 3.0;
    [_scrollview setContentSize:CGSizeMake(self.view.frame.size.width, 580)];
    
    if (_is_Edit) {
        _lbl_title.text = [NSString stringWithFormat:@"Edit %@",LeadSingular];
        _txt_firstname.text = [NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"firstname"]];
        _txt_lastname.text = [NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"lastname"]];
        _txt_email.text = [NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"email"]];
        _txt_phonenum.text = [NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"phone"]];
        _txt_company.text = [NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"company"]];
        
        if ([[_leadDict valueForKey:@"card"] rangeOfString:@"img_"].location == NSNotFound) {
            [_btn_card setImageForState:UIControlStateNormal withURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",Img_Path,[_leadDict valueForKey:@"card"]]]];
        }else{
            [_btn_card setImage:[UIImage imageWithContentsOfFile:[Document_Directory stringByAppendingPathComponent:[_leadDict valueForKey:@"card"]]] forState:UIControlStateNormal];
        }
        
        if ([[_leadDict valueForKey:@"image"] rangeOfString:@"img_"].location == NSNotFound) {
            [_btn_profilepic setImageForState:UIControlStateNormal withURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",Img_Path,[_leadDict valueForKey:@"image"]]]];
        }else{
            [_btn_profilepic setImage:[UIImage imageWithContentsOfFile:[Document_Directory stringByAppendingPathComponent:[_leadDict valueForKey:@"image"]]] forState:UIControlStateNormal];
        }
        [_btn_add setTitle:@"Update" forState:UIControlStateNormal];
    
    }else{
        _lbl_title.text = [NSString stringWithFormat:@"Add %@",LeadSingular];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)uploadCard:(id)sender {
    camera = [[UIAlertView alloc]initWithTitle:@"Select Image via" message:nil delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Camera",@"Library",nil];
    camera.tag = 1;
    [camera show];
    
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if ([alertView isEqual:camera]) {
        
        if (buttonIndex == 2) {
            [self openLibraryiphone];
        }else if (buttonIndex ==1){
            [self opencameraiphone];
        }
        
    }
    
    
}
-(void)openLibraryiphone
{
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [imagePickerController setDelegate:self];
    [self presentViewController:imagePickerController animated:YES completion:nil];
    
}
-(void)opencameraiphone
{
    UIImagePickerController * imagePickerController = [[UIImagePickerController alloc] init];
    if (![UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear])
    {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Camera not available." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil]  show];
        return;
    }
    imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    [imagePickerController setDelegate:self];
    [self presentViewController:imagePickerController animated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController *)pickerr didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo {
    
    if (camera.tag == 1) {
      
        [_btn_card setImage:image forState:UIControlStateNormal];
    }else{
       
        [_btn_profilepic setImage:image forState:UIControlStateNormal];
    }
    
    [pickerr dismissViewControllerAnimated:YES completion:nil];
}
- (IBAction)uploadProfilePic:(id)sender {
    camera = [[UIAlertView alloc]initWithTitle:@"Select Image via" message:nil delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Camera",@"Library",nil];
    camera.tag = 2;
    [camera show];
}

- (IBAction)goAdd:(id)sender {
    [self.view endEditing:YES];
    
    if([_txt_firstname.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter first name." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }else if([_txt_lastname.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter last name." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    else if (![[ModelClass sharedInstance]validateEmail:[NSString stringWithFormat:@"%@",_txt_email.text]]) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Your email address is not formatted correctly." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    
    }else if([_txt_phonenum.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter phone number." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }
    else if([_txt_company.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length == 0 ) {
        [[[UIAlertView alloc] initWithTitle:@"" message:@"Please enter company name." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
    }

    else{
        DELEGATE.is_refreshList = YES;
        NSString *cardImgPath = @"";
        if (![_btn_card.imageView.image isEqual:[UIImage imageNamed:@"add_image"]]) {
            cardImgPath = [self SaveImageandGetPathOf:_btn_card.imageView.image];
        }
        NSString *profileImgPath = @"";
        if (![_btn_profilepic.imageView.image isEqual:[UIImage imageNamed:@"add_image"]]) {
            profileImgPath = [self SaveImageandGetPathOf:_btn_profilepic.imageView.image];
        }
        if(Is_local){
            if (_is_Edit) {
               [[NSFileManager defaultManager]removeItemAtPath:[Document_Directory stringByAppendingPathComponent:[_leadDict valueForKey:@"card"]] error:nil];
                [[NSFileManager defaultManager]removeItemAtPath:[Document_Directory stringByAppendingPathComponent:[_leadDict valueForKey:@"image"]] error:nil];
                
                [[DatabaseHelper sharedInstance]executeUpdate:
                 [NSString stringWithFormat:@"Update leads Set "
                  @"company = '%@', first_name= '%@',last_name= '%@',email= '%@',phone = '%@',card_image ='%@',pic_image ='%@',u_date= '%@' where id = '%@'",
                  _txt_company.text,_txt_firstname.text,_txt_lastname.text,_txt_email.text,_txt_phonenum.text,cardImgPath,profileImgPath,[NSString stringWithFormat:@"%d",(int)[[NSDate date]timeIntervalSince1970]],[_leadDict valueForKey:@"id"]] andCompletionBlock:^(BOOL success){
                     if (success) {
                        
                         LeadsListViewController  *goleads = [[LeadsListViewController alloc]initWithNibName:@"LeadsListViewController" bundle:nil];
                         goleads.eventDict = _eventDict;
                         
                         NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                         [vcs insertObject:goleads atIndex:[vcs count]-1];
                         [self.navigationController setViewControllers:vcs animated:NO];
                         [self.navigationController popViewControllerAnimated:YES];
                     }else{
                          [[[UIAlertView alloc] initWithTitle:@"" message:@"Please try again later" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                     }
                     
                 }];
            }else{
                
                [[DatabaseHelper sharedInstance]executeUpdate:
                 [NSString stringWithFormat:@"INSERT INTO leads"
                  @"(company, first_name,last_name,email,phone,card_image,pic_image,event_id,i_date)"
                  @"VALUES('%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@')",
                  _txt_company.text,_txt_firstname.text,_txt_lastname.text,_txt_email.text,_txt_phonenum.text,cardImgPath,profileImgPath,[_eventDict valueForKey:@"id"],[NSString stringWithFormat:@"%d",(int)[[NSDate date]timeIntervalSince1970]]] andCompletionBlock:^(BOOL success){
                     if (success) {
                        
                         LeadsListViewController  *goleads = [[LeadsListViewController alloc]initWithNibName:@"LeadsListViewController" bundle:nil];
                         goleads.eventDict = _eventDict;
                         
                         NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                         [vcs insertObject:goleads atIndex:[vcs count]-1];
                         [self.navigationController setViewControllers:vcs animated:NO];
                         [self.navigationController popViewControllerAnimated:YES];
                     }else{
                         [[[UIAlertView alloc] initWithTitle:@"" message:@"Please try again later" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                     }
                     
                 }];
            }
        }else{
            if (_is_Edit) {
                [[ModelClass sharedInstance]AddorEditLeadlistwithparamter:
                 @{@"userid":User_Id,
                   @"event_id":[NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"id"]],
                   @"leadid":[NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"id"]],
                   @"first_name":[NSString stringWithFormat:@"%@",_txt_firstname.text],
                   @"last_name":[NSString stringWithFormat:@"%@",_txt_lastname.text],
                   @"email":[NSString stringWithFormat:@"%@",_txt_email.text],
                   @"phone":[NSString stringWithFormat:@"%@",_txt_phonenum.text],
                   @"company":[NSString stringWithFormat:@"%@",_txt_company.text]
                   }
                    images:[NSMutableArray arrayWithObjects:_btn_card.imageView.image,_btn_profilepic.imageView.image, nil]
                    success:^(id result){
                        if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                            LeadsListViewController  *goleads = [[LeadsListViewController alloc]initWithNibName:@"LeadsListViewController" bundle:nil];
                            goleads.eventDict = _eventDict;
                            
                            NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                            [vcs insertObject:goleads atIndex:[vcs count]-1];
                            [self.navigationController setViewControllers:vcs animated:NO];
                            [self.navigationController popViewControllerAnimated:YES];
                            
                            
                        }else{
                            [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                        }
                        
                    } error:^(NSError *error){
                        
                    }];
            }else{
                [[ModelClass sharedInstance]AddorEditLeadlistwithparamter:
                 @{@"userid":User_Id,
                   @"event_id":[NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"id"]],
                   @"first_name":[NSString stringWithFormat:@"%@",_txt_firstname.text],
                   @"last_name":[NSString stringWithFormat:@"%@",_txt_lastname.text],
                   @"email":[NSString stringWithFormat:@"%@",_txt_email.text],
                   @"phone":[NSString stringWithFormat:@"%@",_txt_phonenum.text],
                   @"company":[NSString stringWithFormat:@"%@",_txt_company.text]
                   }
                    images:[NSMutableArray arrayWithObjects:_btn_card.imageView.image,_btn_profilepic.imageView.image, nil]
                    success:^(id result){
                        if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                            LeadsListViewController  *goleads = [[LeadsListViewController alloc]initWithNibName:@"LeadsListViewController" bundle:nil];
                            goleads.eventDict = _eventDict;
                            NSMutableArray *vcs =  [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
                            [vcs insertObject:goleads atIndex:[vcs count]-1];
                            [self.navigationController setViewControllers:vcs animated:NO];
                            [self.navigationController popViewControllerAnimated:YES];
                        }else{
                            [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                        }
                        
                    } error:^(NSError *error){
                        
                    }];
            }
        }
        
    }
}

- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)goAddressBook:(id)sender {
    ContactsViewController *goCont = [[ContactsViewController alloc]initWithNibName:@"ContactsViewController" bundle:nil];
    goCont.delgate = self;
    [self.navigationController pushViewController:goCont animated:YES];
}
-(void)didContactSelected:(NSMutableDictionary *)contactDict{
    //   NSLog(@"-->%@",contactDict);
    if ([[contactDict valueForKey:@"firstName"]length]>0) {
        _txt_firstname.text = [NSString stringWithFormat:@"%@",[contactDict valueForKey:@"firstName"]];
    }
    if ([[contactDict valueForKey:@"lastName"]length]>0) {
        _txt_lastname.text = [NSString stringWithFormat:@"%@",[contactDict valueForKey:@"lastName"]];
    }
    if ([[contactDict valueForKey:@"emails"]length]>0) {
        _txt_email.text = [NSString stringWithFormat:@"%@",[contactDict valueForKey:@"emails"]];
    }
    if ([[contactDict valueForKey:@"phones"]length]>0) {
        _txt_phonenum.text = [NSString stringWithFormat:@"%@",[contactDict valueForKey:@"phones"]];
    }
    if ([[contactDict valueForKey:@"company"]length]>0) {
        _txt_company.text = [NSString stringWithFormat:@"%@",[contactDict valueForKey:@"company"]];
    }
    if([contactDict valueForKey:@"thumbnail"]) {
        [_btn_profilepic setImage:[contactDict valueForKey:@"thumbnail"] forState:UIControlStateNormal];
    }

    
}

-(NSString *)SaveImageandGetPathOf:(UIImage *)image{
    
    NSString *savedImagePath = [Document_Directory stringByAppendingPathComponent:[NSString stringWithFormat:@"img_%@.png",[DELEGATE getRandomString]]];
    NSData *imageData = UIImagePNGRepresentation([[ModelClass sharedInstance]scaleAndRotateImage:image]);
    [imageData writeToFile:savedImagePath atomically:NO];
    return [savedImagePath lastPathComponent];
}

@end
