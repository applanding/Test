//
//  ContactsViewController.m
//  MeetingTalks
//
//  Created by Applanding Solutions on 01/07/15.
//  Copyright (c) 2015 Applanding Solutions. All rights reserved.
//

#import "ContactsViewController.h"

@interface ContactsViewController ()

@end

@implementation ContactsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    APAddressBook *addressBook = [[APAddressBook alloc] init];
    addressBook.sortDescriptors = @[
                                    [NSSortDescriptor sortDescriptorWithKey:@"firstName" ascending:YES],
                                    [NSSortDescriptor sortDescriptorWithKey:@"lastName" ascending:YES]];
    addressBook.fieldsMask = APContactFieldFirstName | APContactFieldLastName | APContactFieldCompany | APContactFieldPhones | APContactFieldEmails | APContactFieldThumbnail;
    // don't forget to show some activity
    [addressBook loadContacts:^(NSArray *contacts, NSError *error)
     {
         // hide activity
         if (!error)
         {
             // do something with contacts array
             contactArr = [[NSMutableArray alloc]init];
             for (APContact *contact in contacts) {
                 
                 NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                 if (contact.firstName) {
                     [dict setObject:[NSString stringWithFormat:@"%@",contact.firstName]forKey:@"firstName"];
                 }else{
                     [dict setObject:@"" forKey:@"firstName"];
                 }
                 if (contact.lastName) {
                     [dict setObject:[NSString stringWithFormat:@"%@",contact.lastName]forKey:@"lastName"];
                 }else{
                     [dict setObject:@"" forKey:@"lastName"];
                 }
                 if (contact.company) {
                     [dict setObject:[NSString stringWithFormat:@"%@",contact.company]forKey:@"company"];
                 }else{
                     [dict setObject:@"" forKey:@"company"];
                 }
                 if ([contact.emails count]>0) {
                     [dict setObject:[NSString stringWithFormat:@"%@",[contact.emails objectAtIndex:0]]forKey:@"emails"];
                 }else{
                     [dict setObject:@"" forKey:@"emails"];
                 }
                 if ([contact.phones count]>0) {
                     [dict setObject:[NSString stringWithFormat:@"%@",[contact.phones objectAtIndex:0]]forKey:@"phones"];
                 }else{
                     [dict setObject:@"" forKey:@"phones"];
                 }
                 if (contact.thumbnail) {
                     [dict setObject:contact.thumbnail forKey:@"thumbnail"];
                 }
                 [contactArr addObject:dict];
             }
             
             
             displayArr = [[NSMutableArray alloc]initWithArray:contactArr];
             [_tableview reloadData];
             
         }
         else
         {
             // show error
             
         }
     }];

    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    
    [displayArr removeAllObjects];
    if (searchBar.text.length > 0){
        NSPredicate *p = [NSPredicate predicateWithFormat:
                          @"SELF['firstName'] CONTAINS [cd] %@ OR SELF['lastName'] CONTAINS [cd] %@ OR SELF['company'] CONTAINS [cd] %@ OR SELF['emails'] CONTAINS [cd] %@ OR SELF['phones'] CONTAINS [cd] %@", searchBar.text,searchBar.text,searchBar.text,searchBar.text,searchBar.text];  // either use beginswith
        [displayArr addObjectsFromArray:[contactArr filteredArrayUsingPredicate:p]];
        
    }else{
        [displayArr addObjectsFromArray:contactArr];
    }
    [_tableview reloadData];
}
#pragma mark - UITableView Delegate and Datasource functions

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return displayArr.count;
}

- (CGFloat)tableView: (UITableView*)tableView heightForRowAtIndexPath: (NSIndexPath*) indexPath {
    return 70;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // Get the desired contact from the filteredContacts array
    
    // Initialize the table view cell
    static NSString *CellIdentifier = @"ContactTableViewCell";
    ContactTableViewCell *cell = (ContactTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell= (ContactTableViewCell *)[arrNib objectAtIndex:0];
        
    }
    cell.backgroundColor = [UIColor colorWithRed:245.0f/255.0f green:245.0f/255.0f blue:245.0f/255.0f alpha:1.0];
    
    // Get the UI elements in the cell;
    UILabel *contactNameLabel = (UILabel *)[cell viewWithTag:101];
    UILabel *mobilePhoneNumberLabel = (UILabel *)[cell viewWithTag:102];
    UIImageView *contactImage = (UIImageView *)[cell viewWithTag:103];
    
    // Assign values to to US elements
    contactNameLabel.text = [NSString stringWithFormat:@"%@ %@",[[displayArr objectAtIndex:indexPath.row]valueForKey:@"firstName"],[[displayArr objectAtIndex:indexPath.row]valueForKey:@"lastName"]];
    
    mobilePhoneNumberLabel.text = [NSString stringWithFormat:@"%@",[[displayArr objectAtIndex:indexPath.row]valueForKey:@"phones"]];
    if([[displayArr objectAtIndex:indexPath.row]valueForKey:@"thumbnail"]) {
        contactImage.image = [[displayArr objectAtIndex:indexPath.row]valueForKey:@"thumbnail"];
    }
    contactImage.layer.masksToBounds = YES;
    contactImage.layer.cornerRadius = 20;
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Hide Keyboard
    
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if ([self.delgate respondsToSelector:@selector(didContactSelected:)]) {
        [self.delgate didContactSelected:[displayArr objectAtIndex:indexPath.row]];
    }
    [self goBack:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
@end
