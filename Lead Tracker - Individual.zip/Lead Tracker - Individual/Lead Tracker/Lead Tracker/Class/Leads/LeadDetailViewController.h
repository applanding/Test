//
//  LeadDetailViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 01/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddLeadViewController.h"
#import "POVoiceHUD.h"
#import "FSAudioStream.h"
#import "FSAudioController.h"
#import "FSPlaylistItem.h"
#import "FSFrequencyDomainAnalyzer.h"
#import "FSFrequencyPlotView.h"
#import "AJNotificationView.h"
#import "LPlaceholderTextView.h"

@interface LeadDetailViewController : UIViewController<POVoiceHUDDelegate,UITableViewDataSource, UITableViewDelegate,FSPCMAudioStreamDelegate,UITextViewDelegate>
{
   
    BOOL isLoadingMore;
    BOOL canLoadMore;
    NSMutableArray *displayarr;
    NSMutableArray *originalarr;
   
    
    NSTimer *_progressUpdateTimer;
    FSPlaylistItem *_selectedPlaylistItem;
    FSAudioController *_controller;
    
}
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (nonatomic,strong) UIButton *playButton;
@property (nonatomic,strong) FSPlaylistItem *selectedPlaylistItem;
@property (nonatomic,strong) UISlider *progressSlider;
@property (nonatomic,strong) FSAudioController *audioController;
 @property (nonatomic, retain) DemoTableFooterView *footerView;
@property (nonatomic, retain) POVoiceHUD *voiceHud;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
- (IBAction)goBack:(id)sender;
- (IBAction)goEdit:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl_eventName;
@property (weak, nonatomic) IBOutlet UILabel *lbl_leadname;
@property (weak, nonatomic) IBOutlet UITextView *lbl_email;
@property (weak, nonatomic) IBOutlet UITextView *lbl_phonenum;
@property (weak, nonatomic) IBOutlet UITextView *lbl_company;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (retain, nonatomic) NSMutableDictionary *eventDict;
@property (retain,nonatomic) NSMutableDictionary *leadDict;
@property (weak, nonatomic) IBOutlet UIImageView *img_profile;
@property (weak, nonatomic) IBOutlet UIImageView *img_card;
@property (weak, nonatomic) IBOutlet UIView *view_comment;
@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollview_comment;
@property (weak, nonatomic) IBOutlet UIView *view_addcomment;
- (IBAction)closeCommentView:(id)sender;

@property (weak, nonatomic) IBOutlet LPlaceholderTextView *txt_comment;
@property (weak, nonatomic) IBOutlet UIButton *btn_send;
- (IBAction)goSend:(id)sender;
- (IBAction)addComment:(id)sender;
@property (weak, nonatomic) IBOutlet UISearchBar *txt_search;
@end
