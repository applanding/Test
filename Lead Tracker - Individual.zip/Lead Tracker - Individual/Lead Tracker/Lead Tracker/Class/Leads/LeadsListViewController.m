//
//  LeadsListViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 01/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "LeadsListViewController.h"

@interface LeadsListViewController ()

@end

@implementation LeadsListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _lbl_title.text = LeadPlural;
    _footerView = (DemoTableFooterView *) [[[NSBundle mainBundle] loadNibNamed:@"DemoTableFooterView" owner:self options:nil] objectAtIndex:0];
   
    _tableview.tableFooterView = _footerView;
    canLoadMore = YES;
    if (Is_local) {
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select * from leads where is_active = 1 and is_deleted = 0 and event_id = '%@' order by i_date desc LIMIT %d OFFSET 0 ",[_eventDict valueForKey:@"id"],Limit] andCompletionBlock:^(FMResultSet *fresults){
            originalarr = [[NSMutableArray alloc]init];
            displayarr = [[NSMutableArray alloc]init];
            while ([fresults next]) {
               
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"card_image"]] forKey:@"card"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"company"]] forKey:@"company"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"email"]] forKey:@"email"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"pic_image"]] forKey:@"image"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"phone"]] forKey:@"phone"];
                 [originalarr addObject:dict];
            }
           displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
            [_tableview reloadData];
            if ([originalarr count] < Limit) {
                canLoadMore = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompleted];
        }];
    }else{
        [[ModelClass sharedInstance]Leadlistwithparamter:
         @{@"userid":User_Id,
           @"eventid":[NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"id"]],
           @"start":@"0",
           @"limit":[NSString stringWithFormat:@"%d",Limit]
           }
            success:^(id result){
                if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                    originalarr = [[NSMutableArray alloc]initWithArray:[result valueForKey:@"Lead"]];
                    displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
                    
                }else{
                    [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                }
                [_tableview reloadData];
                if ([originalarr count] < Limit) {
                    canLoadMore = NO;
                }
                [_tableview reloadData];
                [self loadMoreCompleted];
            } error:^(NSError *error){
                canLoadMore = NO;
            }];
        
    }
    
}
-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return [displayarr count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    static NSString *CellIdentifier = @"LeadTableViewCell";
    LeadTableViewCell *cell = (LeadTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell= (LeadTableViewCell *)[arrNib objectAtIndex:0];
        
    }    cell.selectionStyle=UITableViewCellSelectionStyleNone;

    [cell setBackgroundColor:[UIColor clearColor]];
    cell.lbl_name.text = [NSString stringWithFormat:@"%@ %@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"firstname"],[[displayarr objectAtIndex:indexPath.row]valueForKey:@"lastname"]];
    cell.lbl_email.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"email"]];
    cell.lbl_phonenum.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"phone"]];
    if ([[[displayarr objectAtIndex:indexPath.row]valueForKey:@"image"] rangeOfString:@"img_"].location == NSNotFound) {
    [cell.img_profile setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",Img_Path,[[displayarr objectAtIndex:indexPath.row]valueForKey:@"image"]]] placeholderImage:[UIImage imageNamed:@"placeholder_user"]];
    }else{
        
        cell.img_profile.image = [UIImage imageWithContentsOfFile:[Document_Directory stringByAppendingPathComponent:[[displayarr objectAtIndex:indexPath.row]valueForKey:@"image"]]];
        
    }
    

    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self.view endEditing:YES];
    
    LeadDetailViewController *goLead = [[LeadDetailViewController alloc]initWithNibName:@"LeadDetailViewController" bundle:nil];
    goLead.eventDict = _eventDict;
    goLead.leadDict = [displayarr objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:goLead animated:YES];
    
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //    float endScrolling = scrollView.contentOffset.y + scrollView.frame.size.height;
    //    if (endScrolling >= scrollView.contentSize.height)
    //    {
    //        // your code goes here
    //    }
    
    if (!isLoadingMore && canLoadMore && _txt_search.text.length == 0) {
        CGFloat scrollPosition = scrollView.contentSize.height - scrollView.frame.size.height - scrollView.contentOffset.y;
        if (scrollPosition < [self footerLoadMoreHeight]) {
            [self loadMore];
        }
    }
}
- (CGFloat) footerLoadMoreHeight
{
    if (_footerView)
        return _footerView.frame.size.height;
    else
        return 52;
}
- (BOOL) loadMore
{
    if (isLoadingMore)
        return NO;
    
    [self willBeginLoadingMore];
    isLoadingMore = YES;
    return YES;
}
- (void) willBeginLoadingMore
{
    
    [self.footerView.activityIndicator startAnimating];
    [self performSelector:@selector(addItemsOnBottom) withObject:nil afterDelay:1.0];
}
-(void)addItemsOnBottom{
    if(Is_local){
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"Select * from leads where is_active = 1 and is_deleted = 0 and event_id = '%@' order by i_date desc LIMIT %d OFFSET %d ",[_eventDict valueForKey:@"id"],Limit,(int)[originalarr count]] andCompletionBlock:^(FMResultSet *fresults){
            int rescount = 0;
            while ([fresults next]) {
                rescount++;
               
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"card_image"]] forKey:@"card"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"company"]] forKey:@"company"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"email"]] forKey:@"email"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"pic_image"]] forKey:@"image"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"phone"]] forKey:@"phone"];
                [originalarr addObject:dict];
            }
            displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
            [_tableview reloadData];
             if (rescount  < Limit) {
                canLoadMore = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompleted];
        }];
    }else{
    [[ModelClass sharedInstance]Leadlistwithparamter:
     @{@"userid":User_Id,
       @"eventid":[NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"id"]],
       @"start":[NSString stringWithFormat:@"%d",(int)[originalarr count]],
       @"limit":[NSString stringWithFormat:@"%d",Limit]
       }
      success:^(id result){
          if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
              [originalarr addObjectsFromArray:[result valueForKey:@"Lead"]];
              displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
              if ([[result valueForKey:@"Lead"] count] < Limit) {
                  canLoadMore = NO;
              }
          }else{
            //  [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
               canLoadMore = NO;
          }
          
          [_tableview reloadData];
          
          
          [self loadMoreCompleted];
      } error:^(NSError *error){
          canLoadMore = NO;
      }];
    
    }
}
- (void) loadMoreCompleted
{
    
    
    [self.footerView.activityIndicator stopAnimating];
    isLoadingMore = NO;
    if (!canLoadMore) {
        // Do something if there are no more items to load
        
        // We can hide the footerView by: [self setFooterViewVisibility:NO];
        
        // Just show a textual info that there are no more items to load
        self.footerView.infoLabel.hidden = NO;
    }
}
- (void) setFooterViewVisibility:(BOOL)visible
{
    if (visible && self.tableview.tableFooterView != _footerView)
        self.tableview.tableFooterView = _footerView;
    else if (!visible)
        self.tableview.tableFooterView = nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
    
}
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    [displayarr removeAllObjects];
    
    NSPredicate *p = [NSPredicate predicateWithFormat:@"SELF.firstname CONTAINS[cd] %@ or SELF.lastname CONTAINS[cd] %@ or SELF.email CONTAINS[cd] %@ or SELF.phone CONTAINS[cd] %@", _txt_search.text, _txt_search.text, _txt_search.text,_txt_search.text];
    NSArray *arr = [originalarr filteredArrayUsingPredicate:p];
   
    if ([_txt_search.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0) {
        
        [displayarr addObjectsFromArray:arr];
        
    }else
    {
        [displayarr addObjectsFromArray:originalarr];
        
    }
    [_tableview reloadData];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)goBack:(id)sender {
    BOOL isNavigated = NO;
    for (UIViewController *viewController in [self.navigationController.viewControllers reverseObjectEnumerator]) {
        if ([viewController isKindOfClass:[EventDetailViewController class]]) {
            isNavigated = YES;
            [self.navigationController popToViewController:viewController animated:YES];
            break;
        }
    }
    if (isNavigated == NO) {
        for (UIViewController *viewController in [self.navigationController.viewControllers reverseObjectEnumerator]) {
            if ([viewController isKindOfClass:[SearchViewController class]]) {
                [self.navigationController popToViewController:viewController animated:YES];
                break;
            }
        }
    }
    
}
- (IBAction)addLead:(id)sender {
    AddLeadViewController *addlead = [[AddLeadViewController alloc]initWithNibName:@"AddLeadViewController" bundle:nil];
    addlead.eventDict = _eventDict;
    [self.navigationController pushViewController:addlead animated:YES];
}
@end
