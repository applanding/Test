//
//  ContactTableViewCell.m
//  TenderTiger
//
//  Created by ETL on 03/12/14.
//  Copyright (c) 2014 ETL. All rights reserved.
//

#import "ContactTableViewCell.h"

@implementation ContactTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
