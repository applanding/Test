//
//  AddLeadViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 07/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
#import "UIButton+AFNetworking.h"
#import "ContactsViewController.h"
@interface AddLeadViewController : UIViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIAlertViewDelegate,UITextFieldDelegate,ContactsDelegate>{

    UIAlertView *camera;
}

@property (weak, nonatomic) IBOutlet UITextField *txt_firstname;
@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (weak, nonatomic) IBOutlet UITextField *txt_lastname;
@property (weak, nonatomic) IBOutlet UITextField *txt_email;
@property (weak, nonatomic) IBOutlet UITextField *txt_phonenum;
@property (weak, nonatomic) IBOutlet UITextField *txt_company;
@property (weak, nonatomic) IBOutlet UIButton *btn_card;
- (IBAction)uploadCard:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn_profilepic;
- (IBAction)uploadProfilePic:(id)sender;
- (IBAction)goAdd:(id)sender;
- (IBAction)goBack:(id)sender;
@property (assign,nonatomic) bool is_Edit;
@property (retain, nonatomic) NSMutableDictionary *eventDict;
@property (retain, nonatomic) NSMutableDictionary *leadDict;

@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *scrollview;
@property (weak, nonatomic) IBOutlet UIImageView *img_firstname;
@property (weak, nonatomic) IBOutlet UIImageView *img_lastname;
@property (weak, nonatomic) IBOutlet UIImageView *img_email;
@property (weak, nonatomic) IBOutlet UIImageView *img_phonenum;
@property (weak, nonatomic) IBOutlet UIButton *btn_add;
- (IBAction)goAddressBook:(id)sender;

@end
