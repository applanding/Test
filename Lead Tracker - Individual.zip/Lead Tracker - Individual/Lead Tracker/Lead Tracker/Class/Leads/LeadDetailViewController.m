//
//  LeadDetailViewController.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 01/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "LeadDetailViewController.h"

@interface LeadDetailViewController ()

@end

@implementation LeadDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _lbl_title.text = [NSString stringWithFormat:@"%@ Detail",LeadSingular];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hidekeyboard)];
    [_scrollview addGestureRecognizer:tap];
    
     _selectedPlaylistItem = [[FSPlaylistItem alloc]init];
    
    _lbl_eventName.text = [NSString stringWithFormat:@"%@",[_eventDict valueForKey:@"name"]];;
    _lbl_leadname.text = [NSString stringWithFormat:@"%@ %@",[_leadDict valueForKey:@"firstname"],[_leadDict valueForKey:@"lastname"]];
    _lbl_email.text = [NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"email"]];
    _lbl_phonenum.text = [NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"phone"]];
    _lbl_company.text = [NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"company"]];
    
    if ([[_leadDict valueForKey:@"card"] rangeOfString:@"img_"].location == NSNotFound) {
      [_img_card setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",Img_Path,[_leadDict valueForKey:@"card"]]] placeholderImage:nil];
    }else{
        [_img_card setImage:[UIImage imageWithContentsOfFile:[Document_Directory stringByAppendingPathComponent:[_leadDict valueForKey:@"card"]]]];
        
    }
    
    if ([[_leadDict valueForKey:@"image"] rangeOfString:@"img_"].location == NSNotFound) {
       [_img_profile setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",Img_Path,[_leadDict valueForKey:@"image"]]] placeholderImage:[UIImage imageNamed:@"placeholder_user"]];
    }else{
        [_img_profile setImage:[UIImage imageWithContentsOfFile:[Document_Directory stringByAppendingPathComponent:[_leadDict valueForKey:@"image"]]]];
    }
    
    
    _view_addcomment.layer.cornerRadius = 5.0;
    _txt_comment.layer.cornerRadius = 5.0;
      _txt_comment.placeholderText = @"Type here...";
    self.voiceHud = [[POVoiceHUD alloc] initWithParentView:self.view];
    self.voiceHud.title = @"Speak Now";
    
    [self.voiceHud setDelegate:self];
    [self.view addSubview:self.voiceHud];
    [self CallCommentListAPI];
    
    
}
-(void)hidekeyboard{
    [self.view endEditing:YES];
}

-(void)viewWillAppear:(BOOL)animated{
   
    
    [self.audioController setVolume:1.0];
    
    self.audioController.stream.onStateChange = ^(FSAudioStreamState state) {
        switch (state) {
            case kFsAudioStreamRetrievingURL:
                [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
                
                [self showStatus:@"Retrieving URL..."];
                
                self.progressSlider.enabled = NO;
                self.playButton.selected = YES;
                
                
                break;
                
            case kFsAudioStreamStopped:
                [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                
                
                
                self.progressSlider.enabled = NO;
                self.playButton.selected = NO;
                
                
                break;
                
            case kFsAudioStreamBuffering:
                [self showStatus:@"Buffering..."];
                
                [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
                self.progressSlider.enabled = NO;
                self.playButton.selected = YES;
                
                break;
                
            case kFsAudioStreamSeeking:
                [self showStatus:@"Seeking..."];
                
                [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
                self.progressSlider.enabled = NO;
                self.playButton.selected = YES;
                
                break;
                
            case kFsAudioStreamPlaying:
                
                [self clearStatus];
                
                [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                
                self.progressSlider.enabled = YES;
                
                if (!_progressUpdateTimer) {
                    _progressUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                                                            target:self
                                                                          selector:@selector(updatePlaybackProgress)
                                                                          userInfo:nil
                                                                           repeats:YES];
                }
                
                self.playButton.selected = YES;
                
                
                
                break;
                
            case kFsAudioStreamFailed:
                [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                self.progressSlider.enabled = NO;
                self.playButton.selected = NO;
                
                
                break;
            default:
                break;
        }
    };
    
    self.audioController.stream.onFailure = ^(FSAudioStreamError error, NSString *errorDescription) {
        NSString *errorCategory;
        
        switch (error) {
            case kFsAudioStreamErrorOpen:
                errorCategory = @"Cannot open the audio stream: ";
                break;
            case kFsAudioStreamErrorStreamParse:
                errorCategory = @"Cannot read the audio stream: ";
                break;
            case kFsAudioStreamErrorNetwork:
                errorCategory = @"Network failed: cannot play the audio stream: ";
                break;
            case kFsAudioStreamErrorUnsupportedFormat:
                errorCategory = @"Unsupported format: ";
                break;
            case kFsAudioStreamErrorStreamBouncing:
                errorCategory = @"Network failed: cannot get enough data to play: ";
                break;
            default:
                errorCategory = @"Unknown error occurred: ";
                break;
        }
        
        NSString *formattedError = [NSString stringWithFormat:@"%@ %@", errorCategory, errorDescription];
        
        [self showErrorStatus:formattedError];
    };
    
}
-(void)viewDidAppear:(BOOL)animated{
    [self becomeFirstResponder];
    
    _progressUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                                            target:self
                                                          selector:@selector(updatePlaybackProgress)
                                                          userInfo:nil
                                                           repeats:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)CallCommentListAPI{
    
    _footerView = (DemoTableFooterView *) [[[NSBundle mainBundle] loadNibNamed:@"DemoTableFooterView" owner:self options:nil] objectAtIndex:0];
    _tableview.tableFooterView = _footerView;
    canLoadMore = YES;
    if(Is_local){
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"select comments.id,comments.comment,comments.type,comments.audio_file,comments.i_date,leads.first_name,leads.last_name from comments Inner Join leads on leads.id = comments.lead_id where comments.is_active = 1 and comments.is_deleted = 0 and comments.event_id='%@' and comments.lead_id ='%@' order by comments.i_date desc LIMIT %d OFFSET 0 ",[_eventDict valueForKey:@"id"],[_leadDict valueForKey:@"id"],Limit] andCompletionBlock:^(FMResultSet *fresults){
            originalarr = [[NSMutableArray alloc]init];
            displayarr = [[NSMutableArray alloc]init];
            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];
            
            NSDateFormatter *_timeformat = [[NSDateFormatter alloc] init];
            [_timeformat setDateFormat:@"hh:mm a"];
            while ([fresults next]) {
               
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"audio_file"]] forKey:@"audio"];
                
                NSDate *commentdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"i_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:commentdate] forKey:@"date"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"comment"]] forKey:@"text"];
                [dict setObject:@"T" forKey:@"type"];
                if([[[fresults resultDictionary]valueForKey:@"type"]intValue]==1){
                    [dict setObject:@"A" forKey:@"type"];
                }
                [dict setObject:[_timeformat stringFromDate:commentdate] forKey:@"time"];
                [originalarr addObject:dict];
            }
            displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
            if ([originalarr count] < Limit) {
                canLoadMore = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompleted];
            _tableview.hidden = NO;
            [self AdjustFrames];
        }];
    }else{
    [[ModelClass sharedInstance]LeadCommentlistwithparamter:
     @{@"userid":User_Id,
       @"leadid":[NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"id"]],
       @"start":@"0",
       @"limit":[NSString stringWithFormat:@"%d",Limit]
       }
        success:^(id result){
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                originalarr = [[NSMutableArray alloc]initWithArray:[result valueForKey:@"Comment"]];
                displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
                
            }else{
                //   [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            }
            
            if ([originalarr count] < Limit) {
                canLoadMore = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompleted];
            _tableview.hidden = NO;
            [self AdjustFrames];
        } error:^(NSError *error){
            canLoadMore = NO;
        }];
    }
    
}
-(void)AdjustFrames{
    [_tableview setFrame:CGRectMake(_tableview.frame.origin.x, _tableview.frame.origin.y, _tableview.frame.size.width, [self tableViwHeight])];
    [_scrollview setContentSize:CGSizeMake(_scrollview.frame.size.width, _tableview.frame.origin.y + _tableview.frame.size.height + 50)];
    
}
- (CGFloat)tableViwHeight
{
    [_tableview layoutIfNeeded];
    
    return [_tableview contentSize].height;
}
- (IBAction)goBack:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)goEdit:(id)sender {
    AddLeadViewController *editLead = [[AddLeadViewController alloc]initWithNibName:@"AddLeadViewController" bundle:nil];
    editLead.is_Edit = YES;
    editLead.eventDict = _eventDict;
    editLead.leadDict = _leadDict;
    [self.navigationController pushViewController:editLead animated:YES];
}
- (IBAction)closeCommentView:(id)sender {
    [self.view endEditing:YES];
    _view_comment.hidden = YES;
}
- (IBAction)goSend:(id)sender {
    [self.view endEditing:YES];
    if (_btn_send.isSelected) {
        if ([_txt_comment.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length >0) {
            if(Is_local){
                [[DatabaseHelper sharedInstance]executeUpdate:
                 [NSString stringWithFormat:@"INSERT INTO comments"
                  @"(event_id, lead_id,comment,i_date)"
                  @"VALUES('%@', '%@', '%@', '%@')",
                  [_eventDict valueForKey:@"id"],[_leadDict valueForKey:@"id"],_txt_comment.text,[NSString stringWithFormat:@"%d",(int)[[NSDate date]timeIntervalSince1970]]] andCompletionBlock:^(BOOL success){
                     if (success) {
                        
                         _view_comment.hidden = YES;
                         DELEGATE.is_refresh = YES;
                         [self performSelector:@selector(CallCommentListAPI) withObject:nil afterDelay:0.3];
                     }else{
                          [[[UIAlertView alloc] initWithTitle:@"" message:@"Please try again later" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                     }
                     
                 }];
            }else{
           [[ModelClass sharedInstance]AddCommentwithparamter:
            @{@"userid":User_Id,
              @"leadid":[NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"id"]],
              @"comment":[NSString stringWithFormat:@"%@",_txt_comment.text],
              @"audio":@""
              } is_audio:NO success:
            ^(id result){
                if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                    _view_comment.hidden = YES;
                    DELEGATE.is_refresh = YES;
                    [self CallCommentListAPI];
                }else{
                    [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                }
            } error:^(NSError *error){
            
            }];
            }
        }
    }else{
        [self.voiceHud startForFilePath:[NSTemporaryDirectory() stringByAppendingString:@"RecordedFile"]];
    }
}

- (IBAction)addComment:(id)sender {
    
    if (Is_local) {
//       NSInteger commentcount = [[DatabaseHelper sharedInstance].db intForQuery:[NSString stringWithFormat:@"select count(*) from comments where is_active = 1 and is_deleted = 0"]];
//        if (commentcount >=Max_Local_Comment) {
//            [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"You can add maximum %d Notes per user. Either delete old Notes or contact at www.meetingtalks.com for more.",Max_Local_Comment] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
//        }else{
            _txt_comment.text = @"";
            _btn_send.selected = NO;
            _view_comment.hidden = NO;
//        }
    }else{
        [[ModelClass sharedInstance]GetCommentCountwithparamter:@{@"userid":User_Id} success:^(id result){
            
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                if ([[result valueForKey:@"commentcount"]intValue]>=[[result valueForKey:@"limit"]intValue]) {
                    [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"You can add maximum %@ Notes per user. Either delete older Notes or contact at www.meetingtalks.com for more.",[result valueForKey:@"limit"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                }else{
                    _txt_comment.text = @"";
                    _btn_send.selected = NO;
                    _view_comment.hidden = NO;
                }
            }
        } error:^(NSError *error){
            
        }];
    
    }
    
    
    
    
}

- (IBAction)commentTextType:(id)sender {
    if ([_txt_comment.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0) {
        _btn_send.selected = YES;
    }else
    {
        _btn_send.selected = NO;
    }
}
- (void)POVoiceHUD:(POVoiceHUD *)voiceHUD voiceRecorded:(NSString *)recordPath length:(float)recordLength {
    NSLog(@"Sound recorded with file %@ for %.2f seconds", recordPath , recordLength);
    
    if (Is_local) {
        NSString *destination = [Document_Directory stringByAppendingPathComponent:[NSString stringWithFormat:@"aud_%@.mp3",[DELEGATE getRandomString]]];
        NSError *error;
        [[NSFileManager defaultManager]copyItemAtPath:[NSHomeDirectory() stringByAppendingFormat:@"/Documents/%@", @"Mp3File.mp3"] toPath:destination error:&error];
        if (!error) {
            [[DatabaseHelper sharedInstance]executeUpdate:
             [NSString stringWithFormat:@"INSERT INTO comments"
              @"(event_id, lead_id,type,audio_file,i_date)"
              @"VALUES('%@', '%@', '%@', '%@', '%@')",
              [_eventDict valueForKey:@"id"],[_leadDict valueForKey:@"id"],@"1",[destination lastPathComponent],[NSString stringWithFormat:@"%d",(int)[[NSDate date]timeIntervalSince1970]]] andCompletionBlock:^(BOOL success){
                 if (success) {
                    
                     _view_comment.hidden = YES;
                     DELEGATE.is_refresh = YES;
                     [self performSelector:@selector(CallCommentListAPI) withObject:nil afterDelay:0.3];
                 }else{
                    [[[UIAlertView alloc] initWithTitle:@"" message:@"Please try again later" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
                 }
                 

             }];
        }
    }else{
        [[ModelClass sharedInstance]AddCommentwithparamter:
         @{@"userid":User_Id,
           @"leadid":[NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"id"]],
           @"comment":@"",
           } is_audio:YES success:
         ^(id result){
             if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                 _view_comment.hidden = YES;
                 DELEGATE.is_refresh = YES;
                 [self CallCommentListAPI];
             }else{
                 [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
             }
         } error:^(NSError *error){
             
         }];
    }
    
}

- (void)voiceRecordCancelledByUser:(POVoiceHUD *)voiceHUD {
    NSLog(@"Voice recording cancelled for HUD: %@", voiceHUD);
}

- (void)textViewDidChange:(UITextView *)textView{
    if ([_txt_comment.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0) {
        _btn_send.selected = YES;
    }else
    {
        _btn_send.selected = NO;
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
    
}
-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    
    return [displayarr count];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([[[displayarr objectAtIndex:indexPath.row]valueForKey:@"type"]isEqualToString:@"T"]) {
        
        return  [[NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"text"]] sizeWithFont:[UIFont systemFontOfSize:14]constrainedToSize:CGSizeMake(320 - 17, MAXFLOAT)lineBreakMode:NSLineBreakByWordWrapping].height + 55;
    }
    
    return 80;
}
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CommentTableViewCell *cell;
    if ([[[displayarr objectAtIndex:indexPath.row]valueForKey:@"type"]isEqualToString:@"T"]) {
        
        static NSString *CellIdentifier = @"CommentTableViewCell";
        cell = (CommentTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell==nil) {
            NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell= (CommentTableViewCell *)[arrNib objectAtIndex:0];
        }
        cell.lbl_comment.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"text"]];
        [cell.lbl_comment sizeToFit];
        [cell.lbl_date setFrame:CGRectMake(cell.lbl_date.frame.origin.x, cell.lbl_comment.frame.origin.y + cell.lbl_comment.frame.size.height + 5, cell.lbl_date.frame.size.width, cell.lbl_date.frame.size.height)];
        [cell.lbl_time setCenter:CGPointMake(cell.lbl_time.center.x, cell.lbl_date.center.y)];
        
    }else{
        static NSString *CellIdentifier = @"AudioCommentTableViewCell";
        cell = (CommentTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell==nil) {
            NSArray *arrNib=[[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell= (CommentTableViewCell *)[arrNib objectAtIndex:0];
        }
        cell.btn_play.tag = indexPath.row;
        [cell.btn_play addTarget:self action:@selector(PlayComment:) forControlEvents:UIControlEventTouchUpInside];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.lbl_name.text = [NSString stringWithFormat:@"%@ %@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"firstname"],[[displayarr objectAtIndex:indexPath.row]valueForKey:@"lastname"]];
    cell.lbl_date.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"date"]];
    cell.lbl_time.text = [NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"time"]];
    return cell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        if (Is_local) {
            [[DatabaseHelper sharedInstance]executeUpdate:[NSString stringWithFormat:@"Update comments set is_active = 0 and is_deleted = 1 where id = %@ ",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"id"]] andCompletionBlock:^(BOOL Success){
                if (Success) {
                    if (![[[displayarr objectAtIndex:indexPath.row]valueForKey:@"type"]isEqualToString:@"T"]) {
                        [[NSFileManager defaultManager]removeItemAtPath:[Document_Directory stringByAppendingPathComponent:[[displayarr objectAtIndex:indexPath.row]valueForKey:@"audio"]] error:nil];
                    }
                     DELEGATE.is_refresh = YES;
                    [originalarr removeObject:[displayarr objectAtIndex:indexPath.row]];
                    [displayarr removeObjectAtIndex:indexPath.row];
                    [_tableview deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationFade];
                }
            }];
        }else{
            [[ModelClass sharedInstance]DeleteRecordwithparamter:
             @{@"typeid":[NSString stringWithFormat:@"%@",[[displayarr objectAtIndex:indexPath.row]valueForKey:@"id"]],
               @"type":@"c"
               } success:^(id result){
                    DELEGATE.is_refresh = YES;
                   [originalarr removeObject:[displayarr objectAtIndex:indexPath.row]];
                   [displayarr removeObjectAtIndex:indexPath.row];
                   [_tableview deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationFade];
               } error:^(NSError *error){
                   
               }];
        }
    }
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //    float endScrolling = scrollView.contentOffset.y + scrollView.frame.size.height;
    //    if (endScrolling >= scrollView.contentSize.height)
    //    {
    //        // your code goes here
    //    }
    
    if (!isLoadingMore && canLoadMore && _txt_search.text.length == 0) {
        CGFloat scrollPosition = scrollView.contentSize.height - scrollView.frame.size.height - scrollView.contentOffset.y;
        if (scrollPosition < [self footerLoadMoreHeight]) {
            [self loadMore];
        }
    }
}
- (CGFloat) footerLoadMoreHeight
{
    if (_footerView)
        return _footerView.frame.size.height;
    else
        return 52;
}
- (BOOL) loadMore
{
    if (isLoadingMore)
        return NO;
    
    [self willBeginLoadingMore];
    isLoadingMore = YES;
    return YES;
}
- (void) willBeginLoadingMore
{
    
    [self.footerView.activityIndicator startAnimating];
    [self performSelector:@selector(addItemsOnBottom) withObject:nil afterDelay:1.0];
}
-(void)addItemsOnBottom{
    if(Is_local){
        [[DatabaseHelper sharedInstance]executeQuery:[NSString stringWithFormat:@"select comments.id,comments.comment,comments.type,comments.audio_file,comments.i_date,leads.first_name,leads.last_name from comments Inner Join leads on leads.id = comments.lead_id where comments.is_active = 1 and comments.is_deleted = 0 and comments.event_id='%@' and comments.lead_id ='%@' order by comments.i_date desc LIMIT %d OFFSET %d ",[_eventDict valueForKey:@"id"],[_leadDict valueForKey:@"id"],Limit,(int)[originalarr count]] andCompletionBlock:^(FMResultSet *fresults){

            NSDateFormatter *_dateformat = [[NSDateFormatter alloc] init];
            [_dateformat setDateFormat:@"MM/dd/yyyy"];
            
            NSDateFormatter *_timeformat = [[NSDateFormatter alloc] init];
            [_timeformat setDateFormat:@"hh:mm a"];
            int rescount = 0;
            while ([fresults next]) {
                rescount++;
                
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"id"]] forKey:@"id"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"audio_file"]] forKey:@"audio"];
                
                NSDate *commentdate = [NSDate dateWithTimeIntervalSince1970:[[[fresults resultDictionary]valueForKey:@"i_date"]intValue]];
                [dict setObject:[_dateformat stringFromDate:commentdate] forKey:@"date"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"first_name"]] forKey:@"firstname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"last_name"]] forKey:@"lastname"];
                [dict setObject:[NSString stringWithFormat:@"%@",[[fresults resultDictionary]valueForKey:@"comment"]] forKey:@"text"];
                [dict setObject:@"T" forKey:@"type"];
                if([[[fresults resultDictionary]valueForKey:@"type"]intValue]==1){
                    [dict setObject:@"A" forKey:@"type"];
                }
                [dict setObject:[_timeformat stringFromDate:commentdate] forKey:@"time"];
                [originalarr addObject:dict];
            }
            displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
            if (rescount < Limit) {
                canLoadMore = NO;
            }
            [_tableview reloadData];
            [self loadMoreCompleted];
            [self AdjustFrames];
        }];
    }else{
    [[ModelClass sharedInstance]LeadCommentlistwithparamter:
     @{@"userid":User_Id,
       @"leadid":[NSString stringWithFormat:@"%@",[_leadDict valueForKey:@"id"]],
       @"start":[NSString stringWithFormat:@"%d",(int)[originalarr count]],
       @"limit":[NSString stringWithFormat:@"%d",Limit]
       }
        success:^(id result){
            if ([[NSString stringWithFormat:@"%@",[result valueForKey:@"status"]]boolValue]) {
                [originalarr addObjectsFromArray:[result valueForKey:@"Comment"]];
                displayarr = [[NSMutableArray alloc]initWithArray:originalarr];
                if ([[result valueForKey:@"Comment"]count] < Limit) {
                    canLoadMore = NO;
                }
            }else{
                canLoadMore = NO;
                //  [[[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil]  show];
            }
            
            
            [_tableview reloadData];
            [self loadMoreCompleted];
             [self AdjustFrames];
            
        } error:^(NSError *error){
            canLoadMore = NO;
        }];
    }
    
    
    
}

- (void) loadMoreCompleted
{
    
    
    [self.footerView.activityIndicator stopAnimating];
    isLoadingMore = NO;
    if (!canLoadMore) {
        // Do something if there are no more items to load
        
        // We can hide the footerView by: [self setFooterViewVisibility:NO];
        
        // Just show a textual info that there are no more items to load
        self.footerView.infoLabel.hidden = NO;
    }
}
- (void) setFooterViewVisibility:(BOOL)visible
{
    if (visible && self.tableview.tableFooterView != _footerView)
        self.tableview.tableFooterView = _footerView;
    else if (!visible)
        self.tableview.tableFooterView = nil;
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
    
}

-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    [displayarr removeAllObjects];
    
    NSPredicate *p = [NSPredicate predicateWithFormat:@"SELF.firstname CONTAINS[cd] %@ or SELF.lastname CONTAINS[cd] %@ or SELF.text CONTAINS[cd] %@ or SELF.date CONTAINS[cd] %@ or SELF.time CONTAINS[cd] %@", _txt_search.text, _txt_search.text, _txt_search.text,_txt_search.text,_txt_search.text];
    NSArray *arr = [originalarr filteredArrayUsingPredicate:p];
    
    if ([_txt_search.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length > 0) {
        
        [displayarr addObjectsFromArray:arr];
        
    }else
    {
        [displayarr addObjectsFromArray:originalarr];
        
    }
    [_tableview reloadData];
     [self AdjustFrames];
}
-(void)PlayComment:(UIButton *)sender{
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback
                                     withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker
                                           error:nil];
    [self.view endEditing:YES];
    if (sender.isSelected) {
        //playing already
        [self.audioController pause];
        [self.audioController stop];
        sender.selected = NO;
    }else{
        
        _playButton.selected = NO;
        _progressSlider.value = 0.0;
        CommentTableViewCell *cell = (CommentTableViewCell*)[_tableview cellForRowAtIndexPath:[NSIndexPath indexPathForRow:sender.tag inSection:0]];
        for (UIView *view in cell.contentView.subviews){
            
            if ([view isKindOfClass:[UISlider class]]) {
                _progressSlider = (UISlider *)view;
                break;
            }
        }
        for (UIView *view in cell.contentView.subviews){
            
            if ([view isKindOfClass:[UIButton class]]) {
                _playButton = (UIButton *)view;
                break;
            }
        }
        FSPlaylistItem *item = [[FSPlaylistItem alloc]init];
        
        if ([[[displayarr objectAtIndex:sender.tag]valueForKey:@"audio"] rangeOfString:@"aud_"].location == NSNotFound) {
            
            item.url = [NSString stringWithFormat:@"%@/%@",Img_Path,[[displayarr objectAtIndex:sender.tag]valueForKey:@"audio"]];
        }else{
            item.url = [Document_Directory stringByAppendingPathComponent:[[displayarr objectAtIndex:sender.tag]valueForKey:@"audio"]];
        }
        [self setSelectedPlaylistItem:item];
        [self.audioController play];
        sender.selected = YES;
    }
    
    
    
}
- (FSAudioController *)audioController
{
    if (!_audioController) {
        _audioController = [[FSAudioController alloc] init];
    }
    return _audioController;
}
- (void)setSelectedPlaylistItem:(FSPlaylistItem *)selectedPlaylistItem
{
    _selectedPlaylistItem = selectedPlaylistItem;
    
    self.navigationItem.title = self.selectedPlaylistItem.title;
    
    self.audioController.url = self.selectedPlaylistItem.nsURL;
}

- (FSPlaylistItem *)selectedPlaylistItem
{
    return _selectedPlaylistItem;
}

- (void)clearStatus
{
    [AJNotificationView hideCurrentNotificationViewAndClearQueue];
}

- (void)showStatus:(NSString *)status
{
    [self clearStatus];
    
    [AJNotificationView showNoticeInView:[[[UIApplication sharedApplication] delegate] window]
                                    type:AJNotificationTypeDefault
                                   title:status
                         linedBackground:AJLinedBackgroundTypeAnimated
                               hideAfter:0];
}

- (void)showErrorStatus:(NSString *)status
{
    [self clearStatus];
    
    [AJNotificationView showNoticeInView:[[[UIApplication sharedApplication] delegate] window]
                                    type:AJNotificationTypeRed
                                   title:status
                               hideAfter:10];
}

- (void)updatePlaybackProgress
{
    if (self.audioController.stream.continuous) {
        self.progressSlider.enabled = NO;
        self.progressSlider.value = 0;
        
    } else {
        self.progressSlider.enabled = YES;
        
        FSStreamPosition cur = self.audioController.stream.currentTimePlayed;
        FSStreamPosition end = self.audioController.stream.duration;
        [_progressSlider setMaximumValue: (end.minute*60)+end.second];
        [_progressSlider setValue:cur.playbackTimeInSeconds animated:YES];
        
        
    }
    
    
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
    
    [self resignFirstResponder];
    
    
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    // Free the resources (audio queue, etc.)
    _audioController = nil;
    
    if (_progressUpdateTimer) {
        [_progressUpdateTimer invalidate], _progressUpdateTimer = nil;
    }
}

@end
