//
//  ContactsViewController.h
//  MeetingTalks
//
//  Created by Applanding Solutions on 01/07/15.
//  Copyright (c) 2015 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "APAddressBook.h"
#import "APContact.h"
#import "ContactTableViewCell.h"
@protocol ContactsDelegate <NSObject>
@optional
-(void)didContactSelected:(NSMutableDictionary *)contactDict;
@end

@interface ContactsViewController : UIViewController<UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate>{
    NSMutableArray *contactArr;
    NSMutableArray *displayArr;

}
@property(nonatomic,weak) id<ContactsDelegate>delgate;
- (IBAction)goBack:(id)sender;

@property (weak, nonatomic) IBOutlet UITableView *tableview;
@end
