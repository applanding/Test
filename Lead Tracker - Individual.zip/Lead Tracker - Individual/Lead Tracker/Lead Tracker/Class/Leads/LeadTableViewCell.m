//
//  LeadTableViewCell.m
//  Lead Tracker
//
//  Created by Applanding Solutions on 01/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import "LeadTableViewCell.h"

@implementation LeadTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
