//
//  LeadsListViewController.h
//  Lead Tracker
//
//  Created by Applanding Solutions on 01/12/14.
//  Copyright (c) 2014 Applanding Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeadTableViewCell.h"
#import "AddLeadViewController.h"
#import "UIImageView+AFNetworking.h"
#import "LeadDetailViewController.h"
@interface LeadsListViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>{
    NSMutableArray *displayarr;
    NSMutableArray *originalarr;
    BOOL isLoadingMore;
    BOOL canLoadMore;
}

@property (weak, nonatomic) IBOutlet UILabel *lbl_title;
@property (retain, nonatomic) NSMutableDictionary *eventDict;
- (IBAction)goBack:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
- (IBAction)addLead:(id)sender;
@property (weak, nonatomic) IBOutlet UISearchBar *txt_search;
@property (nonatomic, retain) DemoTableFooterView *footerView;
@end
